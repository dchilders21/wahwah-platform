#!/usr/bin/env python

import SimpleHTTPServer
import BaseHTTPServer
import SocketServer
import urllib
import urllib2
import sys
import os

from urlparse import urlparse


class HTTPServer(SocketServer.ThreadingMixIn, BaseHTTPServer.HTTPServer):
    pass


class RequestHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):

    def translate_path(self, path):
        return os.path.join(self.root, path[1:])

    def do_POST(self):
        self.proxy_request()

    def do_PUT(self):
        self.proxy_request()

    def do_DELETE(self):
        self.proxy_request()

    def send_head(self):
        raw_path = self.translate_path(self.path)
        part = urlparse(raw_path)
        path = part.path

        f = None
        if os.path.isdir(path):
            for index in "index.html", "index.htm":
                index = os.path.join(path, index)
                if os.path.exists(index):
                    path = index
                    break
            else:
                self.send_error(404, "File not found")

        ctype = self.guess_type(path)
        try:
            f = open(path, 'rb')
        except IOError:
            self.proxy_request()
            return None

        self.send_response(200)
        self.send_header("Content-type", ctype)
        fs = os.fstat(f.fileno())
        self.send_header("Content-Length", str(fs[6]))
        self.send_header("Last-Modified", self.date_time_string(fs.st_mtime))
        self.no_cache_headers()
        self.end_headers()
        return f

    def no_cache_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")

    def proxy_request(self):
        if not self.proxy_enabled:
            self.send_error(404, "File not found")
            return

        ACCEPTED_HEADERS = [
            'User-Agent', 'Set-Cookie', 'Connection', 'Cookie', 'Content-Type',
            'Transfer-Encoding', 'Date', 'Content-Language', 'Cache-Control',
            'Last-Modified', 'Access-Control-Allow-Origin', 'Vary',
        ]

        headers = {}
        for item in self.headers.__dict__['headers']:
            parsed = item.replace('\r\n', '').partition(': ')
            header = parsed[0]
            value = parsed[2]

            if header in ACCEPTED_HEADERS:
                headers[header] = value

        url = self.proxy + self.path
        requestline = self.requestline.split(" ")
        requestline[1] = url
        self.requestline = " ".join(requestline)

        try:
            length = int(self.headers.getheader('content-length'))
            data = self.rfile.read(length)
        except TypeError:
            data = None

        request = urllib2.Request(url, headers=headers, data=data)
        request.get_method = lambda: self.command

        try:
            response = urllib2.urlopen(request)
        except urllib2.HTTPError as response:
            pass

        self.send_response(response.getcode())

        for item in response.headers.__dict__['headers']:
            parsed = item.replace('\r\n', '').partition(': ')
            header = parsed[0]
            value = parsed[2]

            if header in ACCEPTED_HEADERS:
                self.send_header(header, value)

        self.no_cache_headers()
        self.end_headers()
        self.wfile.write("\r\n")
        self.wfile.write(response.read())
        response.close()

        return

    def log_message(self, format, *args):
        sys.stderr.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), format%args))


def runserver():
    port = 8008
    proxy = None
    root = os.getcwd()

    if sys.argv[1:]:
        port = int(sys.argv[1])

    if sys.argv[2:]:
        proxy = sys.argv[2]

    if sys.argv[3:]:
        root = sys.argv[3]

    server_address = ('', port)

    RequestHandler.proxy = proxy
    RequestHandler.proxy_enabled = proxy is not None

    if os.path.isabs(root):
        RequestHandler.root = root
    else:
        RequestHandler.root = os.path.join(os.getcwd(), root)

    httpd = HTTPServer(server_address, RequestHandler)

    sa = httpd.socket.getsockname()
    print "Server started on '{0}' using port '{1}'".format(sa[0], sa[1])
    if RequestHandler.proxy_enabled:
        print "Proxying HTTP for '{0}'".format(proxy)

    httpd.serve_forever()

if __name__ == "__main__":
    runserver()

