# Up & Running

## App Installation

It is highly recommended use create a virtual environment using [virtualenv](http://www.virtualenv.org/en/latest/).

```
cd cfg; pip install -r pip.requirements.txt
```

## Front end 

You need to have Ruby with RubyGems installed. Macs Have a prebuilt version of Ruby and RubyGems that ships with their OS. 

```
cd src/dashboard 
```

```
gem install bundler
bundle install
```
```
foreman start
```
## Gems Installed

1. [Sass](http://sass-lang.com) - Prepocessor for CSS
2. [Compass](http://compass-style.org) - CSS authoring framework
3. [Guard](http://compass-style.org) - Handle events on file system modifications
4. [Guard CoffeeScript](http://compass-style.org) - Guard::CoffeeScript automatically compiles your CoffeeScripts
5. [Guard Sass](http://compass-style.org) - Guard::Sass automatically rebuilds sass files when modified 
5. [Guard LiveReload](http://compass-style.org) - Guard::LiveReload automatically reload your browser when 'view' files are modified
