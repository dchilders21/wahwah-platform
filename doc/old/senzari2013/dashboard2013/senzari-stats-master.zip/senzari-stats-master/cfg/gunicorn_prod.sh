#!/bin/bash

NAME='dashboard-production'
LOG_LEVEL='info'
DJANGO_DIR=/var/apps/dashboard/production/dashboard
APP_DIR=/var/apps/dashboard/cfg/production/dashboard
SOCKFILE=$APP_DIR/gunicorn.sock
USER=www-data
GROUP=www-data
NUM_WORKERS=5

echo "Starting $NAME"

# Virtual environment.
source $APP_DIR/bin/activate
export PYTHONPATH=$DJANGO_DIR:$PYTHONPATH

# Start Django/Gunicorn
cd $DJANGO_DIR
exec gunicorn_django \
	--name $NAME \
	--workers $NUM_WORKERS \
	--user=$USER --group=$GROUP \
	--log-level=$LOG_LEVEL \
	#--bind=unix:$SOCKFILE

