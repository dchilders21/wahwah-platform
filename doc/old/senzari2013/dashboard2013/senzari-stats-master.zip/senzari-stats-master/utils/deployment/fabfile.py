
import datetime
import json
import os
import requests

from functools import wraps
from types import StringTypes

from fabric.api import *

#
# Global variables.
#
ssh_key_filename = 'senzari_dev.pem'
site_name = 'dashboard'
branch = 'master'
frontend_rootpath = '/var/apps/'
extra_rootpath = '/opt/'

excluded_files = [
    '.sass-cache',
    '*pyc'
]

#
# Utility functions section.
# (Oh, dear lord, I'd love to be able to use a function before declaring it,
# and not remember the old C days. Now we have almost have spagetti code.)
#
def _get_home_ssh_key_path():
    return os.path.join(os.environ.get('HOME'), '.ssh/{0}'.format(ssh_key_filename))

#
# Fabric variables/settings.
#
env.key_filename = _get_home_ssh_key_path()
env.rootpath = frontend_rootpath
env.user = 'root'

env.roledefs = {
    'web_prod': ['54.82.119.151'],
    'web_qa': ['54.82.119.151'],

    'statsd': ['54.82.119.151'],

    'statsd_nodes': [
        'ec2-54-225-53-73.compute-1.amazonaws.com',
        'ec2-23-22-78-214.compute-1.amazonaws.com',
    ]
}

campfire_settings = {
    'api_key': "984240baee5ebade759be039fb9f789a3a980b71",
    'url': "https://senzari.campfirenow.com/room/453676/speak.json"
}

#
# Actual logic.
#

def megatron_log(message):
    data = {
        'message': {
            'body': message
        }
    }
    data = json.dumps(data)
    headers = {'content-type': 'application/json'}

    r = requests.post(campfire_settings['url'], auth=(campfire_settings['api_key'], 'X'), data=data, headers=headers)
    if r.ok:
        print 'MEGATRON SAID: {0}'.format(message)
    else:
        print 'Error sending message to MEGATRON: {0}'.format(message)

def _get_excluded_flags():

    excluded = ''
    for exc in excluded_files:
        excluded = excluded + ' --exclude "{0}"'.format(exc)

    return excluded

def mkdir(path):
    with (settings(warn_only=True)): # Do not fail in case it already exists.
        run('mkdir {0}'.format(path))

def deploy(branch, environment):

    destfile = 'dashboard-{0}.tar.gz'.format(datetime.date.today())
    excluded = _get_excluded_flags()

    local('tar czvf /tmp/dashboard.tar.gz {0} -C ../../src dashboard'.format(excluded))
    put('/tmp/dashboard.tar.gz', '/tmp/{0}'.format(destfile))
    put('../../cfg/pip.requirements.txt', '{0}{1}/cfg/{2}/'.format(frontend_rootpath, site_name, environment))

    megatron_log('SHIP IT')
    megatron_log('DEPLOYING DASHBOARD:{0} TO {1}...'.format(branch, environment))

    with cd('{0}{1}/{2}'.format(frontend_rootpath, site_name, environment)):
        run('rm -fr dashboard-old')
        run('mv dashboard dashboard-old')

        run('tar xzvf /tmp/{0}'.format(destfile))
        run('cp dashboard/settings{0}.py dashboard/settingslocal.py'.format(environment))

        run('../cfg/{0}/dashboard/bin/pip install -r ../cfg/{0}/pip.requirements.txt'.format(environment))
        run('../cfg/{0}/dashboard/bin/python dashboard/manage.py syncdb'.format(environment))
        run('../cfg/{0}/dashboard/bin/python dashboard/manage.py migrate'.format(environment))
        run('../cfg/{0}/dashboard/bin/python dashboard/manage.py collectstatic --noinput'.format(environment))

    reload_http(environment)

@roles('web_prod')
def deploy_production(branch='master'):
    deploy(branch, environment='production')

@roles('web_qa')
def deploy_qa(branch='master'):
    deploy(branch, environment='qa')

def reload_http(environment):
    environment = 'prod' if environment == 'production' else environment

    sudo('supervisorctl restart gunicorn_{0}'.format(environment), pty=True)
    sudo('service memcached restart', pty=True)
    sudo('service nginx restart', pty=True)

@roles('statsd_nodes')
def deploy_statsd_http():
    mkdir('{0}statsd-http'.format(extra_rootpath))

    put('../../src/statsd-http/*js', '{0}statsd-http/'.format(extra_rootpath))
    put('../../src/statsd-http/npm.requirements.txt', '{0}statsd-http/'.format(extra_rootpath))

    # Install deps.
    with cd('{0}statsd-http'.format(extra_rootpath)):
        sudo('cat npm.requirements.txt | while read req; do npm install $req; done')

    sudo('supervisorctl restart statsd-http', pty=True)

