#!/bin/bash

HOST=root@statsd.senzari.net
KEY=~/.ssh/senzari_dev.pem
APPDIR=/var/apps/dashboard/production

#
# Move our current stuff to the statsd server.
#
rm /tmp/dashboard.tar.gz
tar czvf /tmp/dashboard.tar.gz -C ../../src dashboard/
scp -i $KEY /tmp/dashboard.tar.gz $HOST:/tmp/

#
# 1. Backup the old version, just in case.
# 2. Rename.
# 3. Restart services.
#
echo '----------------------------------------'
echo ' Extracting in the server...'

# We *need* bash in order to use 'source'
ssh -i $KEY $HOST /bin/bash <<\EOF
cd /var/apps/dashboard/production/
rm -fr dashboard-old/
mv dashboard/ dashboard-old/
tar xzvf /tmp/dashboard.tar.gz

source /var/apps/dashboard/cfg/production/dashboard/bin/activate
cd dashboard/
cp settingsprod.py settingslocal.py
python manage.py migrate
python manage.py collectstatic --noinput

echo "About to restart the services..."
supervisorctl restart gunicorn_prod
service memcached restart
service nginx restart

EOF

echo 'Deployed done'

