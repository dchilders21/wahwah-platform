{
  port: 8130, // Our Http port

  statsdHost: '127.0.0.1',
  statsdPort: 8125, // Udp port

  sentryDSN: "https://d3adf602e5db4f61bb7731fdbc0c7f4f:a75fff5b866d43a28f48bac576fbe02f@app.getsentry.com/14051",

  debug: true
}

