
StatsdHttp = require ('./server').StatsdHttp;

server = new StatsdHttp(8130, 'localhost', 8125, 3000, true);
server.start ();

server.processStat({
	id: '007',
	name: 'James Bond',
	value: 69,
	type: 'counter',
	widget: 1
});

console.log ('Stat sent, waiting for it to be recollected...');

