from django import http
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect, QueryDict
from django.shortcuts import render_to_response, get_object_or_404
from django.utils.translation import ugettext_lazy, ugettext as _
from django.template import RequestContext
from django.conf import settings


@login_required
@user_passes_test(lambda u: u.is_superuser)
def admin_index(request):
    """
    View for the admin index page
    """
    return render_to_response('core/admin/index.html', {}, RequestContext(request))
