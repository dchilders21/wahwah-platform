from datetime import date, timedelta

from django.conf.urls.defaults import *

from tastypie.authentication import Authentication
from tastypie.authorization import Authorization

from tastypie import fields
from tastypie.exceptions import ImmediateHttpResponse
from tastypie.http import HttpUnauthorized, HttpBadRequest, HttpForbidden
from tastypie.resources import Resource as BaseResource, ModelResource as BaseModelResource, ALL_WITH_RELATIONS
from tastypie.utils import trailing_slash

from django.core.cache import cache

period_choices = {
    'd' : 'days',
    'm' : 'months',
    'y' : 'years'
}

class AttrDict(object):
    """
    Allows you to access the keys of a dictionary
    as if they were attributes of an object.
    """
    def __init__(self, *args, **kwargs):
        # Get the kwargs from the first argument..
        # this is because python is quite retarded and
        # won't allow kwargs to have unicode keys.
        if len(args) == 1 and hasattr(args[0], 'keys'):
            kwargs.update(args[0])


        self._dict = {}
        for key, val in kwargs.items():
            self._dict[str(key)] = val

        self.__dict__.update(self._dict)
        super(AttrDict, self).__init__()

    def to_dict(self):
        return self._dict


class DjangoAuthentication(Authentication):
    """ Basic django authentication """

    def is_authenticated(self, request, **kwargs):
        return request.user.is_authenticated()


    # Optional but recommended
    def get_identifier(self, request):
        return request.user.username


class Resource(BaseResource):
    """ Model resource base class """

    pass


class ModelResource(BaseModelResource):
    """ Model resource base class """

    pass


class StatsResource(Resource):
    """
    Base resource for exposing statistical data
    """
    x = fields.IntegerField(attribute='x')
    y = fields.IntegerField(attribute='y')

    def get_resource_uri(self, *args, **kwargs):
        return ''

    def base_urls(self):
        return []  # Wipe out the base urls.. were not going to use them.

    def override_urls(self):
        return [
                url(r"^(?P<resource_name>%s)%s$" % (self._meta.resource_name, trailing_slash()), self.wrap_view('dispatch_list'), name="api_station_list"),
            ]

    def alter_list_data_to_serialize(self, request, data):
        resp = super(StatsResource, self).alter_list_data_to_serialize(request, data)
        resp['meta']['key'] = self._meta.key
        return resp

    def format_values(x, y):
        """
        Can be overriden to format values
        """
        return { 'x': x, 'y': y }

    def get_values(self, request, **kwargs):
        cursor = connections['default'].cursor()
        sql, params = self.get_sql(request, **kwargs)
        cursor.execute(sql, params)
        data = cursor.fetchall()

        items = []
        for x in data:
            items.append(AttrDict( **self.format_values(x[0], x[1]) ))
        return items

    def obj_get_list(self, request, **kwargs):
        # Get cursor
        params_key = request.path + self.get_cache_key_for_params(request.GET)
        cached_values = cache.get(params_key)
        if cached_values != None:
            return cached_values

        values = self.get_values(request, **kwargs)

        cache.set(params_key, values)
        return values

    def get_cache_key_for_params(self, params):
        # Maybe children should be able to specify/override these ones.
        valid_params = ['period']
        sorted_params = []

        for p in valid_params:
            if p in params:
                value = params [p]
                sorted_params.append('{0}={1}'.format (p, value))

        if len(sorted_params) == 0:
            return ''

        sorted_params.sort()
        return ';'.join(sorted_params)

    @property
    def default_start_date(self):
        return date.today() - timedelta(days=90)

    @property
    def default_end_date(self):
        return date.today()

    def parse_date(self, date_value):
        if not date_value or len(date_value) == 0:
            return None

        try:
            retval = date.fromtimestamp(date_value)
        except:
            return None

        return retval

    def parse_period (self, period):
        # I wonder what's the best place to fallback or detect the
        # default value.
        # Also, we could expose it to the children, either as field
        # or as a getter/setter.
        default_period = '3 months'

        length = len (period)
        if length < 2: # Minimum info: value + unit
            return default_period

        unit = period [length - 1:].lower ()
        if not period_choices.has_key (unit):
            return default_period

        try:
            value = int(period[:length - 1])
        except ValueError:
            return default_period

        return "{0} {1}".format (value, period_choices [unit])


