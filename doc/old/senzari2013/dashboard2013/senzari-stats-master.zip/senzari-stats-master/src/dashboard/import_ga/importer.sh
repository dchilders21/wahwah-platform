#!/bin/bash

APPDIR='/var/apps/dashboard/'

source $APPDIR/cfg/production/dashboard/bin/activate
cd $APPDIR/production/dashboard/
python manage.py maven import_analytics

