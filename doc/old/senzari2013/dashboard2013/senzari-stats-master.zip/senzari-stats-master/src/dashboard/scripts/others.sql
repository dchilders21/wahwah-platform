CREATE VIEW site_stats AS
SELECT id, widget_id,
    loaded_total AS loaded,
    visitor_total AS unique_visitors,
    streaming_time_count,
    CASE WHEN streaming_time > 0 AND streaming_time_count > 0 THEN
        streaming_time / streaming_time_count
    ELSE
        0
    END AS streaming_time_average,
    site_time_count,
    CASE WHEN site_time > 0 AND site_time_count > 0 THEN
        site_time / site_time_count
    ELSE
        0
    END AS site_time_average,
    "day"
FROM (
    SELECT ROW_NUMBER() OVER (ORDER BY widget_id) AS "id",
        widget_id,
        SUM(CASE WHEN "name" = 'counters.loaded' THEN "value" ELSE 0 END)::INT AS loaded_total,
        SUM(CASE WHEN "name" = 'users.unique' THEN "value" ELSE 0 END)::INT AS visitor_total,
        SUM(CASE WHEN "name" = 'counters.streaming.time' THEN "value" ELSE 0 END) AS streaming_time,
        SUM(CASE WHEN "name" = 'counters.streaming.time.count' THEN "value" ELSE 0 END)::INT AS streaming_time_count,
        SUM(CASE WHEN "name" = 'counters.site.time' THEN "value" ELSE 0 END) AS site_time,
        SUM(CASE WHEN "name" = 'counters.site.time.count' THEN "value" ELSE 0 END)::INT AS site_time_count,
        "day"
    FROM summary_stats
    GROUP BY widget_id, "day"
) AS stats_total;

-- Get all the countries
CREATE VIEW country_stats AS
SELECT "id", widget_id, SUBSTRING("name", '.*\._(\w+)') AS "country", "value", "day"
FROM summary_stats
WHERE "name" LIKE 'counters.loaded_by_country.%'
ORDER BY "day";
