-- *******************************
-- * Summarize `counters.loaded` *
-- *******************************
-- *** Inser place holders only **
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.loaded' AS "key",
--    SUM("value") AS "value",
    0.0 as "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.loaded.%'
GROUP BY widget_id, "day";

-- ****************************
-- * Summarize `users.unique` *
-- ****************************
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT widget_id,
    'users.unique' AS "key",
    COUNT(visitor_id) AS total_unique_visitors,
    "day"
FROM (
    SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
        SUBSTRING("name" FROM '.*.\_w\d+\._(.*)') AS visitor_id,
        "day"
    FROM daily_stats
    WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
        AND "name" LIKE 'counters.site.time%'
) AS total_visitors
GROUP BY "day", widget_id;

-- ******************************************
-- * Summarize `counters.loaded_by_country` *
-- ******************************************
-- *** Inser place holders only **
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT "data".widget_id, 
    'counters.loaded_by_country' || "data"."key" AS "key",
--    SUM("data"."value") AS "value",
    0.0 AS "value",
    "data"."day"
FROM (
    SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
        CASE WHEN SUBSTRING("name" FROM '.*.\_w\d+(.*)') = '' THEN '._unknown' ELSE SUBSTRING("name" FROM '.*.\_w\d+(.*)') END AS "key",
--        SUM("value") AS "value",
        0.0 AS "value",
        "day"
    FROM daily_stats
    WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
        AND "name" LIKE 'counters.loaded_by_country%'
    GROUP BY widget_id, "key", "day"
) AS "data"
GROUP BY "data".widget_id, "data"."key", "data"."day";

-- ***************************************************************************
-- * Summarize `counters.streaming.time` and `counters.streaming.time.count` *
-- ***************************************************************************
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.streaming.time' AS "key",
    SUM("value") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.streaming.time%'
GROUP BY widget_id, "key", "day"
UNION
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.streaming.time.count' AS "key",
    COUNT("id") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.streaming.time%'
GROUP BY widget_id, "key", "day";

-- ***************************************************************************
-- * Summarize `counters.stations.plays` and `counters.stations.plays.count` *
-- ***************************************************************************
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.stations.plays' AS "key",
    SUM("value") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.stations.plays%'
GROUP BY widget_id, "key", "day"
UNION
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.stations.plays.count' AS "key",
    COUNT("id") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.stations.plays%'
GROUP BY widget_id, "key", "day";

-- ***************************************************************
-- * Summarize `counter.site.time` and `counter.site.time.count` *
-- ***************************************************************
INSERT INTO summary_stats (widget_id, "name", "value", "day")
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.site.time' AS "key",
    SUM("value") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.site.time%'
GROUP BY widget_id, "key", "day"
UNION
SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
    'counters.site.time.count' AS "key",
    COUNT("id") AS "value",
    "day"
FROM daily_stats
WHERE "day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
    AND "name" LIKE 'counters.site.time%'
GROUP BY widget_id, "key", "day";


-- CREATE TABLE "public"."summary_stats" (
--  "id" serial PRIMARY KEY,
--  "widget_id" int4 NOT NULL,
--  "name" varchar(255) NOT NULL,
--  "value" float8 NOT NULL,
--  "day" date NOT NULL
-- )
