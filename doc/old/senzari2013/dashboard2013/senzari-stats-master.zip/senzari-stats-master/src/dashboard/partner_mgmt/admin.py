
from django.contrib import admin
from models import WidgetUser, WidgetNetwork


class WidgetUserAdmin(admin.ModelAdmin):
    list_display = ['widget_id', 'user', '_get_full_name', 'email',]
    search_fields = ['widget_id', 'user__first_name', 'email']

admin.site.register(WidgetUser, WidgetUserAdmin)


class WidgetNetworkAdmin(admin.ModelAdmin):
    list_display = ['id', 'name',]

admin.site.register(WidgetNetwork, WidgetNetworkAdmin)

