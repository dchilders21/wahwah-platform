# Require any additional compass plugins here.

# Set this to the root of your project when deployed:
# Sass Paths
 http_path = '/'
 http_images_path = 'static/img'

css_dir = "static_files/css"
sass_dir = "static_files/scss"
images_dir = "static_files/img"
javascripts_dir = "static_files/js"
fonts_dir = "static_files/fonts"

output_style = :nested

relative_assets = true

# To disable debugging comments that display the original location of your selectors. Uncomment:
# line_comments = false
color_output = false


# If you prefer the indented syntax, you might want to regenerate this
# project again passing --syntax sass, or you can uncomment this:
# preferred_syntax = :sass
# and then run:
# sass-convert -R --from scss --to sass static_files/scss scss && rm -rf sass && mv scss sass
