from datetime import datetime
import urllib
import uuid

from django import template
from django.template import Context


#
# These chart types are from nvd3.js
#
CHART_TYPES = {
    # 2d charts
    'line': 'lineChart',
    'stackedArea': 'stackedAreaChart',
    'discreteBar': 'discreteBarChart',
    'multiBar': 'multiBarChart',
    'multiBarHorizontal': 'multiBarHorizontalChart',
    'linePlusBar': 'linePlusBarChart',
    'cumulativeLine': 'cumulativeLineChart',
    'lineWithFocus': 'lineWithFocusChart',
    'pie': 'pieChart',
    'bullet': 'bulletChart',

    # 3d charts
    'scatterChart': 'scatterChart',
}

class Chart(object):
    """
    An object representing a chart
    """
    def __init__(self, request, **kwargs):


        super(Chart, self).__init__()

        # Set the default values of the chart
        self._id = None # We will generate a unique hash for this later.
        self.url = request.path
        self.period = request.GET.get('period', '3m')
        self.width = kwargs.get('width', '100%')
        self.height = kwargs.get('height', '400px')
        self.type = request.GET.get('type', kwargs.get('type', 'line'))
        self.x_type = self.type_to_str(kwargs.get('x_type', datetime))
        self.x_format = kwargs.get('x_format', self._default_format(self.x_type))
        self.y_type = self.type_to_str(kwargs.get('y_type', int))
        self.y_format = kwargs.get('y_format', self._default_format(self.y_type))
        self._sources = kwargs.get('sources', [])

        if self.type not in CHART_TYPES:
            raise ValueError('Invalid chart type')


    def _default_format(self, t):
        """
        Returns the default format for a type

        for a list of supported formats, see:
'
            https://github.com/mbostock/d3/wiki/Formatting
            https://github.com/mbostock/d3/wiki/Time-Formatting

        """
        if t == 'int':
            return ',f'

        elif t == 'float':
            return ',.02f'

        elif t == 'datetime':
            return '%x'

        return '%x'

    @property
    def id(self):
        """
        The ID of this chart
        """
        # Generate a unique hash id
        if not self._id:
            self._id = str(uuid.uuid1())
        return self._id

    @property
    def chart_type(self):
        """
        Returns the chart type
        """
        return CHART_TYPES.get(self.type)

    @property
    def has_secondary(self):
        return self.type in ['lineWithFocus']

    @property
    def has_axis(self):
        return self.type in ['line', 'lineWithFocus', 'discreteBar',]

    @property
    def period_description(self):
        if 'm' in self.period:
            num = int(self.period.replace('m', ''))
            fmt = '{0} month' if num == '1' else '{0} months'
        else:
            num = int(self.period.replace('d', ''))
            fmt = '{0} day' if num == '1' else '{0} days'

        return fmt.format(num)

    @property
    def sources(self):

        def format_url(url, period):
            separator = '&' if '?' in url else '?'
            return '{0}{1}period={2}'.format(url, separator, period)

        return [format_url(x, self.period) for x in self._sources]


    def __unicode__(self):
        """
        String representation of the chart
        """
        return self.render()

    def render(self):
        """
        Renders the chart
        """
        t = template.loader.get_template('charts/chart.html')
        return t.render(Context({'chart': self}, autoescape=True))

    def get_url(self, type, value):

        params = {
            'type': self.type,
            'period': self.period,
        }

        params[type] = value

        return '{0}?{1}'.format(self.url, urllib.urlencode(params))

    def type_to_str(self, t):
        return {
            int: 'int',
            str: 'str',
            unicode: 'str',
            datetime: 'datetime',
            float:  'float',
        }[t]

