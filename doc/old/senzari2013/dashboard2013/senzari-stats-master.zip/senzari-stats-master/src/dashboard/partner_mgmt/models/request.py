import logging

from django.conf import settings

import requests
from requests.auth import HTTPDigestAuth
from requests.exceptions import RequestException

log = logging.getLogger(__name__)

def make_request(url, params=None, payload=None, headers=None, method='GET', base_url=None):
    """
    Makes a request to a url

        params are GET querystring parameters
        payload is the content of the POST/PUT calls; its
        supposed to be a JSON encoded payload.

    """
    if not base_url:
        base_url = getattr(settings, 'WIDGET_BASE_URL')

    url = '{0}{1}'.format(base_url, url)

    auth = HTTPDigestAuth(getattr(settings, 'REST_USER'), getattr(settings, 'REST_PASS'))
    method = method.upper()
    try:
        if method == 'GET':
            r = requests.get(url, headers=headers, params=params, auth=auth)
        elif method == 'POST':
            r = requests.post(url, payload, headers=headers, params=params, auth=auth)
        elif method == 'PUT':
            r = requests.put(url, payload, headers=headers, params=params, auth=auth)
        elif method == 'DELETE':
            r = requests.delete(url, auth=auth)
        else:
            message = 'Method "{0}" not supported/recognized.'.format(method)
            log.debug(message)
            raise Exception(message)
    except RequestException as exc:
        log.debug('Got an exception while making a request: {0}'.format(str(exc)))
        raise exc

    # We only expect three possible codes:
    # 200 - OK
    # 201 - Created
    # 202 - Accepted
    if r.status_code < requests.codes.ok or r.status_code > requests.codes.accepted:
        log.debug('Completed a request with an unexpected code:{0}'.format(r.status_code))
        return None

    return r.json


