from django.db import models


class StatsDManager(models.Manager):
    def get_query_set(self):
        qs = super(StatsDManager, self).get_query_set()
        qs = qs.using('stats')
        return qs


class SiteStat(models.Model):
    widget_id = models.IntegerField()
    loaded = models.IntegerField()
    streaming_time_count = models.IntegerField()
    streaming_time_average = models.DecimalField(max_digits=9, decimal_places=2)
    site_time_count = models.IntegerField()
    site_time_average = models.DecimalField(max_digits=9, decimal_places=2)
    day = models.DateField()

    objects = StatsDManager()

    class Meta:
        db_table = 'site_stats'


class CountryStat(models.Model):
    widget_id = models.IntegerField()
    country = models.CharField(max_length=20)
    value = models.IntegerField()
    day = models.DateField()

    objects = StatsDManager()

    class Meta:
        db_table = 'country_stats'


class StationStat(models.Model):
    widget_id = models.IntegerField()
    station_id = models.CharField(max_length=255)
    station_name = models.CharField(max_length=255)
    value = models.IntegerField()
    day = models.DateField()

    objects = StatsDManager()

    class Meta:
        db_table = 'summary_stations'
