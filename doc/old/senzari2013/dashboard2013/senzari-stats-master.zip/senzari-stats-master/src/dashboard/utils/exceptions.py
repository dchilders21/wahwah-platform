from django.http import HttpResponse

class RedirectError(Exception):
    """
    An exception that results in a redirect
    """
    @property
    def response(self, message=None):
        """
        The response to return
        """
        message = message or self.default_message
        return HttpResponse(message, status=self.status)


class NotAuthorizedError(RedirectError):
    """
    Class for not authorized exceptions
    """
    status = 401
    default_message = 'Unauthorized'


class ForbiddenError(RedirectError):
    """
    Class for not authorized exceptions - just some syntactic sugar
    """
    status = 403
    default_message = 'Forbidden'


class NotFoundError(RedirectError):
    """
    Class for not authorized exceptions - just some syntactic sugar
    """
    status = 404
    default_message = 'Forbidden'

