import json
import logging

from django.conf import settings
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.db import models
from django.utils.translation import ugettext as _

from ..models.request import make_request

from utils.decorators import classproperty

class WidgetMenuItemManager(object):
    """
    The manager class to do the persistence
    for the widget menu item objects.
    """
    def get(self, *args, **kwargs):
        """
        """
        params = {}

        if args:
            params['id'] = args[0]
        else:
            params = kwargs


        if 'id' in params and len(params.keys()) == 1:
            data = self._make_request('/api/1.0/widgetmenuitem/{0}'.format(params['id']))
        else:
            data = self._make_request('/api/1.0/widgetmenuitem/', self._normalize_params(params))

        if not data:
            raise ObjectDoesNotExist()

        if isinstance(data, list):

            if len(data) > 1:
                raise MultipleObjectsReturned()

            return WidgetMenuItem.from_rest_data(**data[0])
        else:
            return WidgetMenuItem.from_rest_data(**data)

    def filter(self, **kwargs):
        """
        Filters the widget menu items based on some criteria
        """

        data = self._make_request('/api/1.0/widgetmenuitem/', self._normalize_params(kwargs))
        if not data:
            return []

        retval = []
        for d in data:
            retval.append(WidgetMenuItem.from_rest_data(**d))

        return retval

    def all(self):
        return self.filter()

    def save(self, instance, **kwargs):
        """
        Saves the instance of the widget menu item
        """
        if not instance:
            raise Exception()

        # If the id is 'not assigned' it means we *want* a new one.
        updating = False if instance.id < 0 else self._exists(instance.id)

        if updating:
            method = 'PUT'
            url_part = instance.id
        else:
            method = 'POST'
            url_part = ''

        headers = { 'content-type' : 'application/json' }
        url = '/api/1.0/widgetmenuitem/{0}'.format(url_part)
        payload = self._normalize_payload(instance.to_dict())

        data = self._make_request(url, headers=headers, payload=payload, method=method)
        instance._update_id_info(int(data['id']))

    def delete(self, instance):
        """
        Deletes a specific widget menu item.
        """
        if not instance:
            return

        self.delete_by_id(instance.id)
        instance.id = -1

    def delete_by_id(self, item_id):
        """
        Deletes a widget based on its id.
        """
        if item_id < 0:
            return

        url = '/api/1.0/widgetmenuitem/{0}/'.format(item_id)
        self._make_request(url, method='DELETE')

    def _normalize_payload(self, data):
        """
        Normalizes the WidgetMenuItem data to the format
        our REST api expects.
        """
        data['widget'] = "/api/1.0/widget/{0}/".format(data['widget_id'])

        # Remove data we don't need anymore.
        del data['widget_id']
        del data['id']

        return json.dumps(data)

    def _exists(self, item_id):
        """
        Simplest way to check a widget menu item exists based on its id.
        Return a boolean value.
        """
        if not isinstance(item_id, int) or item_id < 0:
            return False

        data = self._make_request("/api/1.0/widgetmenuitems/{0}".format(item_id))
        return data != None

    def _normalize_params(self, params):
        """
        Pre processes the params passed to the REST api.
        """

        if 'id__in' in params:
            params['ids'] = ','.join([str(val) for val in params['id__in']])
            del params['id__in']

        return params

    def _make_request(self, url, params=None, payload=None, headers=None, method='GET'):
        return make_request(url, params, payload, headers, method)

class WidgetMenuItem(object):
    """
    A class to consume the Senzari REST api
    for WidgetMenuItem manipulation.
    """
    def __init__(self, **kwargs):

        self.id = int(kwargs.get('id', -1))
        self.title = kwargs.get('title', '')
        self.css_class = kwargs.get('css_class', '')
        self.featured_only = kwargs.get('featured_only', False)
        self.is_active = kwargs.get('is_active', True)
        self.station_user_id = kwargs.get('station_user_id', None)
        self.widget_id = kwargs.get('widget_id', None)

    def _update_id_info(self, id):
        self.id = id

    objects = WidgetMenuItemManager()

    @classproperty
    @classmethod
    def DoesNotExist(cls):
        return ObjectDoesNotExist

    @staticmethod
    def from_rest_data(**kwargs):
        """
        Build a new WidgetMenuItem with data retrieved
        using the GET method from the REST api.
        """
        self = WidgetMenuItem(**kwargs)

        # TODO move that method out of the Widget class.
        self.widget_id = Widget._get_id_from_url(kwargs.get('widget'))
        self.station_user_id = Widget._get_id_from_url(kwargs.get('station_user_id'), null=True)

        return self

    def to_dict(self):
        return dict(
            id = self.id,
            title = self.title,
            css_class = self.css_class,
            featured_only = self.featured_only,
            is_active = self.is_active,
            widget_id = self.widget_id,
            station_user_id = self.station_user_id
        )

    def save(self):
        """
        Save or updates the current widget menu item information.
        """
        if self.widget_id == None:
            raise Exception("'widget_id' must be set before saving.")

        if self.station_user_id == None:
            raise Exception("'station_user_id' must be set before saving.")

        # 'id' should be updated in WidgetMenuItemManager.save()
        WidgetMenuItem.objects.save(self)

    def delete(self):
        WidgetMenuItem.objects.delete(self)

