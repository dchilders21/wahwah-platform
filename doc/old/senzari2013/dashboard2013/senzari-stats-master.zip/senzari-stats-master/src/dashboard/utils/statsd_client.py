import statsd

from django.conf import settings

# Similar to the call in the core, but simpler.
def get_statsd():
    return statsd.StatsClient(settings.STATSD_HOST, settings.STATSD_PORT)

