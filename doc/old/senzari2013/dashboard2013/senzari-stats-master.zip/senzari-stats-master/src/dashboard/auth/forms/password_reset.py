#coding=utf-8
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.models import get_current_site
from django.template import Context, loader
from django import forms
from django.utils.http import int_to_base36
from translations import ugettext as _

from core.context_processors import global_settings


class PasswordResetEmailForm(forms.Form):
    """Used for providing extra context to the password reset emails.
    The basics of this are taken from django.contrib.auth.forms
    """
    email = forms.EmailField(label=_("E-mail"), max_length=75)

    def clean_email(self):
        """
        Validates that an active user exists with the given e-mail address.
        """
        email = self.cleaned_data["email"]
        self.users_cache = User.objects.filter(
                                email__iexact=email,
                                is_active=True
                            )
        if len(self.users_cache) == 0:
            raise forms.ValidationError(_("email.pwd-reset.inactive-user"))
        return email

    def save(self, domain_override=None, email_template_name='registration/password_reset_email.html',
             use_https=False, token_generator=default_token_generator, from_email=None, request=None):
        """
        Generates a one-use only link for resetting password and sends to the user
        """
        from django.core.mail import send_mail
        for user in self.users_cache:
            if not domain_override:
                current_site = get_current_site(request)
                site_name = current_site.name
                domain = current_site.domain
            else:
                site_name = domain = domain_override
            t = loader.get_template(email_template_name)
            c = {
                'email': user.email,
                'domain': domain,
                'site_name': site_name,
                'uid': int_to_base36(user.id),
                'user_first': user.first_name,
                'token': token_generator.make_token(user),
                'protocol': use_https and 'https' or 'http',
            }
            global_context = global_settings(None)  # Use None as request
            c.update(global_context)
            send_mail(_("email.pwd-reset.subject"),
                t.render(Context(c)), from_email, [user.email])
