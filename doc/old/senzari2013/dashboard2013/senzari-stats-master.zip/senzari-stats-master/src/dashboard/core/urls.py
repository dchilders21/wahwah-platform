#coding=utf-8
from django.conf.urls.defaults import *
from django.contrib import admin
from django.utils.http import urlquote

from core import views

admin.autodiscover()

urlpatterns = patterns('',
    # Common views
    url(r'^$', views.index, name='index'),
    url(r'^admin/', include(admin.site.urls)),
    #url(r'^admin/$', views.admin_index, name='admin-index'),
    #url(r'^admin/analytics/stations/metrics$', views.station_metrics, name='station-metrics'),
    #url(r'^admin/analytics/users/metrics$', views.user_metrics, name='user-metrics'),

    # Misc views (footer)
    url(r'^about/$', views.about, name='about'),
    url(r'^terms/$', views.terms_of_service, name='terms-of-service'),
    url(r'^privacy/$', views.privacy_policy, name='privacy-policy'),
    url(r'^help/$', views.help, name='help'),
    url(r'^faq/$', views.faq, name='faq'),
)

