from django.contrib.auth.models import User
from django.db import models
from django.utils.translation import ugettext as _

from .rest import *

PARTNER_INDUSTRY_TYPE = (
    (u'Newspaper publisher', _(u'Newspaper publisher')),
)

PARTNER_CONTRACT_TYPE = (
    (u'licence', _(u'Licence')),
    (u'per-stream', _(u'Per stream')),
    (u'revenue-share', _(u'Revenue share'))
)

class PartnerManager(RestObjectManager):
    
    def __init__(self):
        super(PartnerManager, self).__init__()

    def get_url_component(self):
        return 'partners'

    def from_rest_data(self, **kwargs):
        return Partner.from_rest_data(**kwargs)

    def _normalize_payload(self, data):
        return json.dumps(data)

class Partner(RestObject):
    """
    Represents a Senzari partner.
    """

    def __init__(self, **kwargs):
        self.id = int(kwargs.get('id', -1))
        self.name = kwargs.get('name')
        self.contact_name = kwargs.get('contact_name')
        self.contact_email = kwargs.get('contact_email')
        self.contract_type = kwargs.get('contract_type', 'license')
        #active = kwargs.get('active', True)

    objects = PartnerManager()

    @classmethod
    def from_rest_data(cls, **kwargs):
        self = Partner(**kwargs)
        return self

    def __unicode__(self):
        return u'{0}'.format(self.name)

    def to_dict(self):
        return dict(
            id = self.id,
            name = self.name,
            contact_name = self.contact_name,
            contact_email = self.contact_email,
            contract_type = self.contract_type
        )

    def save(self):
        Partner.objects.save(self)

    def delete(self):
        Partner.objects.delete(self)

