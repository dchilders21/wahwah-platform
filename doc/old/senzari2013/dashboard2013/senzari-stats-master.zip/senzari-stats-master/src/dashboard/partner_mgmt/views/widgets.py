#coding=utf-8
import StringIO
import tempfile
import zipfile

from django import http
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.core.servers.basehttp import FileWrapper
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect, QueryDict
from django.shortcuts import render_to_response, get_object_or_404
from django.views.decorators.cache import never_cache
from django.utils.translation import ugettext_lazy, ugettext as _
from django.utils import simplejson as json
from django.views.decorators.cache import cache_page
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.template import RequestContext

from partner_mgmt.forms import WidgetForm, WidgetUserForm
from partner_mgmt.models import Widget, WidgetUser

from utils.exceptions import RedirectError, NotAuthorizedError, ForbiddenError, NotFoundError


def get_widgets(request, widget_id=None):
    """
    Utility function to get the base data for the widget views.
        - Returns a users widgets
        - Returns the widget that the current
          page corresponds to.

        - Raises appropriate exceptions when widget not found or user
          is not authorized to access it.
    """
    widget_id = int(widget_id) if widget_id else None

    try:
        widget = Widget.objects.get(widget_id) if widget_id else None
    except Widget.DoesNotExist:
        raise NotFoundError()

    # shortcirtuit superusers, too many widgets to load, performs faster
    if request.user.is_superuser:
        return (
            widget,
            [widget]
        )

    widget_ids = request.user.widgets.values_list('widget_id', flat=True)
    widgets = {}

    if widget_ids:
        widgets = dict(
            [(x.id, x) for x in Widget.objects.filter(id__in=widget_ids)]
        )

    # Throw an error if the user is requesting a widget_id
    # that does not belong to them
    if widget_id and widget_id not in widgets.keys():
        raise ForbiddenError()

    # Set the widget to the first one if
    # the user did not request one.

    sorted_widgets = sorted(widgets.values(), key=lambda x: x.site_name.lower() if x.site_name else '')

    if sorted_widgets and not widget:
        widget = sorted_widgets[0]

    return (
        widget,
        sorted_widgets
    )


@login_required
def widget_index(request):
    """
    View for the widget index page
    """
    try:
        widget, widgets = get_widgets(request, widget_id=None)
    except RedirectError as ex:
        return ex.response

    if len(widgets) == 0 or (len(widgets) == 1 and widgets[0] is None):
        url = reverse('widget-add')
        return HttpResponseRedirect(url)
    else:
        url = reverse('widget-edit', args=(widget.id,))
        return HttpResponseRedirect(url)


@login_required
def widget_manage_users(request, widget_id):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    data = dict(
        page_name='users',
        widget_id=widget_id,
        widget=widget,
        widgets=widgets
    )
    return render_to_response('partner_mgmt/widgets/users_.html', data, RequestContext(request))


@login_required
def widget_add(request):
    """
    View for partner to add a widget
    """
    widget_id = request.GET.get('widget_id', None)
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
        widget = None
    except RedirectError as ex:
        return ex.response

    form = WidgetForm(user=request.user)

    if request.method == 'POST':
        form = WidgetForm(request.POST, user=request.user)

        if form.is_valid():
            widget = form.save()
            url = reverse('widget-edit', args=(widget.id,))
            return HttpResponseRedirect(url)

    data = dict(
        page_name='settings',
        form=form,
        widget_id=widget_id,
        widget=widget,
        widgets=widgets,
    )

    return render_to_response('partner_mgmt/widgets/settings_.html', data, RequestContext(request))


@login_required
def widget_edit(request, widget_id):
    """
    View for partner to edit a widget
    """
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    form = WidgetForm(instance=widget, user=request.user)

    if request.method == 'POST':
        form = WidgetForm(request.POST, instance=widget, user=request.user)

        if form.is_valid():
            widget = form.save()

    data = dict(
        page_name='edit',
        form=form,
        widget_id=widget_id,
        widget=widget,
        widgets=widgets,
    )

    return render_to_response('partner_mgmt/widgets/settings_.html', data, RequestContext(request))


@login_required
def widget_player_edit(request, widget_id):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    if request.method == 'POST':
        add_artist = request.POST.get('add-artist-value', '').lower().strip()
        delete_artist = request.POST.get('artist-delete', '').lower().strip()

        delete_all = request.POST.get('delete_all_artist', 'false') == 'true' or \
                request.POST.get('feat-stations', '') == 'random'

        if delete_all:
            widget.artists = []
            widget.save()
        elif add_artist and len(widget.artists) < 20 and add_artist not in [x.id for x in widget.artists]:
            widget.artists += [add_artist,]
            widget.save()
        elif delete_artist and delete_artist in [x.id for x in widget.artists]:
            widget.artists = [x for x in widget.artists if not x.id == delete_artist]
            widget.save()

        url = reverse('widget-player-edit', args=(widget.id,))
        return HttpResponseRedirect(url)

    data = dict(
        page_name = 'player',
        widget_id = widget_id,
        widget = widget,
        widgets = widgets,
    )

    return render_to_response('partner_mgmt/widgets/player_.html', data, RequestContext(request))


@login_required
def widget_view(request, widget_id):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    data = dict(
        page_name = 'index',
        widget_id = widget_id,
        widget = widget,
        widgets = widgets,
    )
    return render_to_response('partner_mgmt/widgets/index_.html', data, RequestContext(request))


@login_required
def widget_users(request, widget_id):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    form = WidgetUserForm()
    added_users = []

    if request.method == 'POST':
        added_users = json.loads(request.POST.get('added_users', '[]'))

        if 'add' in request.POST:
            form = WidgetUserForm(request.POST, widget=widget, request=request)
            if form.is_valid():
                user = form.parse()
                if user["email"] not in [x["email"] for x in added_users]:
                    added_users.append(user)

        elif 'delete_user' in request.POST:
            form = WidgetUserForm(request.POST, widget=widget, request=request)
            if form.is_valid():
                form.delete()

        elif 'delete_added_user' in request.POST:
            user_i = int(request.POST.get('delete_added_user')) - 1
            del added_users[user_i]

        # if 'save' in request.POST:
        #     forms = [WidgetUserForm(x, widget=widget) for x in added_users]

        #     for f in forms:
        #         if f.is_valid():
        #             f.save()

        #     added_users = []

        elif 'update_password' in request.POST:
            if request.user.check_password(request.POST['current_password']):
                if len(request.POST['new_password']) != 0:
                    request.user.set_password(request.POST['new_password'])
                    request.user.save()

    data = dict(
        added_users = added_users,
        form = form,
        widget_id = widget_id,
        widget = widget,
        widgets = widgets,
        page_name = 'users',
        current_user = request.user,
    )

    return render_to_response('partner_mgmt/widgets/users_.html', data, RequestContext(request))


@login_required
def widget_code(request, widget_id=None):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    if widget is None:
        return HttpResponseRedirect(reverse('widget-add'))

    data = dict(
        widget_id = widget_id,
        widget = widget,
        widgets = widgets,
        page_name = 'code'
    )
    return render_to_response('partner_mgmt/widgets/code_.html', data, RequestContext(request))


@login_required
def widget_revenue(request, widget_id):
    try:
        widget, widgets = get_widgets(request, widget_id=widget_id)
    except RedirectError as ex:
        return ex.response

    data = dict(
        widget_id = widget_id,
        widget = widget,
        widgets = widgets,
        page_name = 'revenue',
        first_name = request.user.first_name
    )

    return render_to_response('partner_mgmt/widgets/revenue_.html', data, RequestContext(request))


@login_required
def widget_wordpress_plugin(request, widget_id):
    s = StringIO.StringIO()
    zf = zipfile.ZipFile(s, 'w')

    f = tempfile.NamedTemporaryFile()
    f.write(WORDPRESS_PLUGIN_CODE % widget_id)
    f.seek(0) # Force writing to the file.

    zf.write(f.name, 'wahwah/wahwah.php')
    zf.close() # Force writing to the zip file.

    response = HttpResponse(s.getvalue(), mimetype='application/x-zip-compressed')
    response['Content-Disposition'] = 'attachment;filename=wahwah_wp_plugin.zip'
    return response

WORDPRESS_PLUGIN_CODE = """<?php
/*
Plugin Name: WahWah Bar
Plugin URI: http://www.wahwah.co
Description: Integrates the WahWah Radio Bar into a Wordpress Site
Version: 1.0
Author: Senzari, Inc.
Author URI: http://www.wahwah.co
*/


add_action('wp_footer', 'insertWahWahBar');

/*** Bar functions ***/

function insertWahWahBar() {
        $embed_code =<<<HTML1
<script type="text/javascript">
    var _sz = {};
    (function() {
      var s = document.createElement('script'); s.type = "text/javascript";
      s.async = true; s.src = "http://www.senzari.com/widgets/%s/all.js?t=" + (new Date()).valueOf();
      var a = document.getElementsByTagName('script')[0]; a.parentNode.insertBefore(s, a);
    })();
</script>

HTML1;
        echo $embed_code;
}

?>
"""
