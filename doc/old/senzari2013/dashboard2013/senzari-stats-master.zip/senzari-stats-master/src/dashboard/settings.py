from os.path import join as pjoin, dirname, abspath
import logging, sys

gettext = lambda s: s


#
# Sys paths
#
PROJ_ROOT = abspath(dirname(__file__))
lib_path = pjoin(PROJ_ROOT, 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

LOG_FILENAME = pjoin(PROJ_ROOT, 'log', 'dashboard.log')
LOG_LEVEL = logging.DEBUG



TIME_ZONE = 'America/New_York'
SITE_ID = 1

# Localization settings
LANGUAGE_CODE = 'en-us'
USE_I18N = True
USE_L10N = USE_I18N

#
# Paths to media/static dirs
#
MEDIA_ROOT = pjoin(PROJ_ROOT, 'media')
STATIC_ROOT = pjoin(PROJ_ROOT, 'static')
STATIC_URL = '/static/'
ADMIN_MEDIA_PREFIX = '/static/admin/'

STATICFILES_DIRS = (
    pjoin(PROJ_ROOT,'static_files'),
)

STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
)


ADMIN_MEDIA_PREFIX = '/static/admin/'


TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.transaction.TransactionMiddleware',
)


TEMPLATE_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.core.context_processors.debug',
    'django.core.context_processors.i18n',
    'django.core.context_processors.media',
    'django.contrib.messages.context_processors.messages',
    'django.core.context_processors.request',
    'core.context_processors.global_settings',
)

ROOT_URLCONF = 'dashboard.urls'

TEMPLATE_DIRS = (
    pjoin(PROJ_ROOT, 'templates'),
)


INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.humanize',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'django_maven',
    'raven.contrib.django.raven_compat',
    'jstools',
    'registration',
    'shrink',
    'south',
    'tastypie',

    'api',
    'analytics',
    'auth',
    'charts',
    'core',
    'import_ga',
    'partner_mgmt',
    'translations',
    'utils',

    'raven.contrib.django',
)

DATABASE_ROUTERS = ['routers.TranslationRouter']

LOGIN_REDIRECT_URL = '/widgets/'
ACCOUNT_ACTIVATION_DAYS = 30

LANGUAGES = (
    ('en', gettext('English')),
    ('es', gettext('Spanish')),
    ('pt', gettext('Portugues')),
    # ('de', gettext('German')),
)
GET_TRANSLATION_TOKENS_SECONDS = 60 * 60 * 24 * 7 # a week

LOGIN_REDIRECT_URL = '/widgets/'

SITE_NAME = 'Wahwah Pro'

DEFAULT_FROM_EMAIL = 'noreply@wahwah.co'
SUPPORT_EMAIL = 'support@wahwahnetworks.com'

from settingslocal import *

# Set debug according to the
# environment we are in.
DEBUG = True if ENVIRONMENT == 'dev' else False
TEMPLATE_DEBUG = DEBUG
USE_DB_TRANSLATIONS = True

TRANSLATION_CACHE_PREFIX = 'db'

USE_CDN = False if ENVIRONMENT == 'dev' else True

MEDIA_URL = '{0}/media/'.format(BASE_URL)


#
# Database and server settings for the Statsd backend.
#

STATSD_HOST = 'statsd.senzari.net'
STATSD_PORT = 8125


WIDGET_BASE_URLS = {
    'dev': 'http://qa2.senzari.com',
    'qa': 'http://qa.senzari.com',
    'prod': 'http://www.senzari.com',
}

WIDGET_BASE_URL = WIDGET_BASE_URLS[ENVIRONMENT]

REST_USER = 'monkey'
REST_PASS = 'banana'

