# -*- coding: utf-8 -*-

"""
Summarize station

ex.
    ./manage.py summarize_stations
"""
import logging
import sys
import os

from django.core.management.base import BaseCommand
from django.conf import settings
from django.db import connections, transaction

from partner_mgmt.models.request import make_request
from itertools import chain

connection = connections['stats']

log = logging.getLogger(__name__) # Get an instance of a logger
SQL_FILE = os.path.join(os.path.join(settings.PROJ_ROOT, 'scripts'), 'summarize_stations.sql')

class Command(BaseCommand):
    help = 'Summarize top stations'

    def handle(self, *args, **options):
        cursor = connection.cursor()
        data = []

        with open(SQL_FILE) as handle:
            cursor.execute(handle.read().replace('%', '%%'), [])

        row = cursor.fetchone()
        while row:
            response = make_request('/api/1.0/stations/{0}/'.format(row[1]), base_url='http://www.senzari.com')

            if response and 'name' in response:
                data.append(row + (response['name'],))
            else:
                log.warning('id %s is was not found' % row[1])

            row = cursor.fetchone()

        cursor.close()

        self.save_data(data)

    def save_data(self, data):

        header = "INSERT INTO summary_stations (widget_id, station_id, value, day, station_name) VALUES"
        sql = header
        for row in data:
            sql += "(%s, %s, %s, %s, %s),"

        sql = sql[:-1] + ";"

        cursor = connection.cursor()
        cursor.execute(sql, tuple(chain.from_iterable(data)))
        cursor.close()

        # the only way the data will save
        connection.connection.commit()

