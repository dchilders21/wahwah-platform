SELECT widget_id, station_id, "value", "day"
FROM (
    SELECT widget_id, station_id, "value", "day",
        ROW_NUMBER() OVER (PARTITION BY "day", widget_id ORDER BY "value" DESC) AS "row_number"
    FROM (
        SELECT SUBSTRING("name" FROM '.*.\_w(\d+).*')::INT AS widget_id,
            SUBSTRING("name" FROM '.*.\_w\d+\._(.*)') AS station_id,
            SUM("value") AS "value",
            "day"
        FROM daily_stats
        WHERE daily_stats."name" LIKE 'counters.stations.plays%'
            AND daily_stats."day" = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
        GROUP BY widget_id, station_id, "day"
    ) aggregated_stations
) top_stations
WHERE "row_number" <= 5
ORDER BY widget_id;

-- CREATE TABLE "public"."summary_stations" (
--  "id" serial PRIMARY KEY,
--  "widget_id" int4 NOT NULL,
--  "station_id" varchar(255) NOT NULL,
--  "station_name" varchar(255) NOT NULL,
--  "value" float8 NOT NULL,
--  "day" date NOT NULL
-- )