-- insert all the records from yesterday into daily_stats
INSERT INTO daily_stats ("name", "value", "day")
SELECT REPLACE("name", 'stats_counts', 'counters') AS "key", SUM("value"), tstamp::DATE AS "day"
FROM latest_stats
WHERE tstamp::DATE = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE
GROUP BY "day", "key";

-- Delete all yesterdays records from latest_stats
DELETE FROM latest_stats
WHERE tstamp::DATE = (CURRENT_TIMESTAMP(1)::DATE - INTERVAL '1 day')::DATE;