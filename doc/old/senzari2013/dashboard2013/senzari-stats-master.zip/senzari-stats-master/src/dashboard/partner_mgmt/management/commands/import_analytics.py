
import datetime

from django.core.management.base import BaseCommand, CommandError
from import_ga import importer

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        if len(args) > 0:
            parts = args[0].split('-')
            if len(parts) != 3:
                raise Exception('Expected day was not recognized. Format should be: {0}'.format(datetime.date.today()))

            day = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
        else:
            day = datetime.date.today() - datetime.timedelta(days=1)

        importer.import_data(day)

