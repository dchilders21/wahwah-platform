#coding=utf-8

from django.conf.urls.defaults import *

from partner_mgmt import views

urlpatterns = patterns('',

    url(r'^$', views.widget_index, name='index'),
    url(r'^widgets/$', views.widget_index, name='widget-index'),
    url(r'^widgets/add/$', views.widget_add, name='widget-add'),
    url(r'^widgets/(\d+)/$', views.widget_view, name='widget-view'),
    url(r'^widgets/(\d+)/settings/$', views.widget_edit, name='widget-edit'),
    url(r'^widgets/(\d+)/player/edit$', views.widget_player_edit,
        name='widget-player-edit'),
    url(r'^widgets/(\d+)/users/$', views.widget_users, name='widget-users'),
    url(r'widgets/code/$', views.widget_code, name='widget-code'),
    url(r'widgets/(\d+)/code/$', views.widget_code, name='widget-code'),
    url(r'widgets/(\d+)/revenue/$', views.widget_revenue,
        name='widget-revenue'),
    url(r'widgets/(\d+)/wp-plugin/$', views.widget_wordpress_plugin,
        name='widget-wordpress-plugin'),

)
