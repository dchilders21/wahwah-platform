from datetime import date, timedelta
import operator

from django.conf.urls.defaults import *

from tastypie.authentication import Authentication
from tastypie.authorization import Authorization

from tastypie import fields
from tastypie.exceptions import ImmediateHttpResponse
from tastypie.http import HttpUnauthorized, HttpBadRequest, HttpForbidden, HttpNotFound
from tastypie.resources import Resource as BaseResource, ModelResource as BaseModelResource, ALL_WITH_RELATIONS
from tastypie.utils import trailing_slash

from django.core.cache import cache

from utils.isocountries import ISO3166

from ..base import Resource

from partner_mgmt.models import Widget, WidgetStatsCollector, make_request

period_choices = {
    'd' : 'days',
    'm' : 'months',
    'y' : 'years'
}

class JSONField(fields.ApiField):

    def convert(self, value):
        return value

class WidgetStatsContainer(object):
    def __init__(self):
        self.loaded = None
        self.geo = None
        self.stations = None
        self.station_distinct_count = None
        self.onsite_time = None
        self.streaming_time = None

class WidgetStatsResource(Resource):
    """
    Base resource for exposing statistical data
    """
    loaded = JSONField('loaded', default={})
    geo = JSONField('geo', default={})
    stations = JSONField('stations', default={})
    radio_plays = JSONField('radio_plays', default={})
    onsite_time = JSONField('onsite_time', default={})
    onsite_time_count = JSONField('onsite_time_count', default={})
    streaming_time = JSONField('streaming_time', default={})
    station_distinct_count = fields.IntegerField('station_distinct_count', default=0)

    top_stations_count = 5

    def get_resource_uri(self, *args, **kwargs):
        return ''

    def base_urls(self):
        return []  # Wipe out the base urls.. were not going to use them.

    def override_urls(self):
        return [
                url(r"^widget-stats/(?P<pk>[^/]+)%s$" % trailing_slash(), self.wrap_view('dispatch_detail'), name="api_widgetstats_detail"),
            ]

    '''
    def alter_list_data_to_serialize(self, request, data):
        resp = super(StatsResource, self).alter_list_data_to_serialize(request, data)
        resp['meta']['key'] = self._meta.key
        return resp
    '''

    def _get_widget(self, id):
        try:
            widget = Widget.objects.get(id=id)
        except Widget.DoesNotExist:
            raise ImmediateHttpResponse(response=HttpNotFound())

        return widget

    def _get_period(self, request):
        from_date = request.GET.get('from', None)
        to_date = request.GET.get('to', None)

        if not from_date or not to_date:
            return (None, None)

        try:
            # Javascript's timestamps come in milliseconds, not seconds.
            from_date = date.fromtimestamp(int(from_date)/1000.0)
            to_date = date.fromtimestamp(int(to_date)/1000.0)
        except Exception as exc:
            return None

        return (from_date, to_date)

    def get_values(self, request, **kwargs):
        pk = kwargs.get('pk')
        period_from, period_to = self._get_period(request)
        period_days = (period_to - period_from).days

        stats = WidgetStatsCollector.collect_stats(**dict(
            widget_id = pk,
            period_from = period_from,
            period_to = period_to
        ))

        base_days = dict()
        for count in range(0, period_days):
            base_days[(period_from + timedelta(days=count)).strftime("%Y-%m-%d")] = 0.0

        # Main data - conver to the current format if needed.
        onsite = base_days.copy()
        streaming = base_days.copy()
        loaded = base_days.copy()
        onsite_count = stats['onsite_time_count']
        plays = stats['streaming_time_count']
        geo = self._normalize_country_names_(stats['loaded_by_country'])
        stations = self._get_top_(stats['stations'])

        onsite.update(dict(stats['onsite_time']))
        streaming.update(dict(stats['streaming_time']))
        loaded.update(dict(stats['loaded']))

        container = WidgetStatsContainer()
        container.loaded = sorted(loaded.iteritems(), key=operator.itemgetter(0))
        container.geo = geo
        container.stations = stations
        container.onsite_time = sorted(onsite.iteritems(), key=operator.itemgetter(0))
        container.onsite_time_count = onsite_count
        container.streaming_time = sorted(streaming.iteritems(), key=operator.itemgetter(0))
        container.radio_plays = plays
        container.station_distinct_count = 0
        #container.station_distinct_count = station_distinct_count

        return container

    def _get_top_(self, data):
        # sort by value first, then slice to get the top.
        sorted_data = sorted([(key, value) for key, value in data.iteritems()], key=lambda value: value[1], reverse=True)
        sorted_data = sorted_data[0:WidgetStatsResource.top_stations_count]

        # return as a dictionary.
        retval = {}
        for row in sorted_data:
            retval[row[0]] = row[1]

        return retval

    def _normalize_country_names_(self, data):
        country_data = {}
        for key, value in data.iteritems():
            country_name = ISO3166.get(key.upper(), None)
            if not country_name:
                continue # Ignore incomplete data.

            country_name = country_name.lower()
            country_data[country_name] = value

        return country_data

    def obj_get(self, request, **kwargs):
        # Get cursor
        params_key = request.path + self.get_cache_key_for_params(request.GET)
        cached_values = cache.get(params_key)
        if cached_values != None:
            return cached_values

        values = self.get_values(request, **kwargs)

        cache.set(params_key, values)
        return values

    def get_cache_key_for_params(self, params):
        valid_params = ['from', 'to']
        sorted_params = []

        for p in valid_params:
            if p in params:
                value = params [p]
                sorted_params.append('{0}={1}'.format (p, value))

        if len(sorted_params) == 0:
            return ''

        sorted_params.sort()
        return ';'.join(sorted_params)

    @property
    def default_start_date(self):
        return date.today() - timedelta(days=90)

    @property
    def default_end_date(self):
        return date.today()

    def parse_date(self, date_value):
        if not date_value or len(date_value) == 0:
            return None

        try:
            retval = date.fromtimestamp(date_value)
        except:
            return None

        return retval

    def parse_period (self, period):
        # I wonder what's the best place to fallback or detect the
        # default value.
        # Also, we could expose it to the children, either as field
        # or as a getter/setter.
        default_period = '3 months'

        length = len (period)
        if length < 2: # Minimum info: value + unit
            return default_period

        unit = period [length - 1:].lower ()
        if not period_choices.has_key (unit):
            return default_period

        try:
            value = int(period[:length - 1])
        except ValueError:
            return default_period

        return "{0} {1}".format (value, period_choices [unit])

    class Meta:
        key = 'Widget Stats'
        resouce_name = 'widget-stats'
        list_allowed_methods = ['get',]


