import logging
import simplejson
import time

from django.db import connections
from django.conf.urls.defaults import *
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.core.urlresolvers import reverse

from tastypie import fields
from tastypie.exceptions import ImmediateHttpResponse
from tastypie.http import HttpUnauthorized, HttpBadRequest, HttpForbidden
from tastypie.resources import ALL_WITH_RELATIONS
from tastypie.utils import trailing_slash

from ..base import AttrDict, StatsResource, DjangoAuthentication

log = logging.getLogger(__name__)  # Get an instance of a logger

class UniqueListenersResource(StatsResource):
    """ Unique listeners """

    def get_resource_uri(self, *args, **kwargs):
        return ''

    def base_urls(self):
        return []  # Wipe out the base urls.. were not going to use them.

    def override_urls(self):
        return [
                url(r"^(?P<resource_name>%s)%s$" % (self._meta.resource_name, trailing_slash()), self.wrap_view('dispatch_list'), name="api_listeners_list"),
            ]

    def get_values(self, request, **kwargs):
        cursor = connections['prod'].cursor()
        sql = """
            SELECT date_created, sum(count)
            FROM
            ((
            SELECT
                date_trunc('day', play_date) as date_created,
                count(distinct user_id)
                FROM core_trackplayhistory
                WHERE website_id = 2
                AND client_id = 6
                AND play_date > now() - interval %s
                AND user_id is not NULL
                GROUP BY 1
                ORDER BY 1
            ) UNION (
            SELECT
                date_trunc('day', play_date) as date_created,
                count(distinct session_id)
                FROM core_trackplayhistory
                WHERE website_id = 2
                AND client_id = 6
                AND play_date > now() - interval %s
                AND session_id is not NULL
                GROUP BY 1
                ORDER BY 1
            )) as data
            GROUP BY 1
            ORDER BY 1 ASC
        """
        period = self.parse_period (request.GET.get ('period', ''))
        cursor.execute(sql, [period, period])
        data = cursor.fetchall()

        items = []
        for x in data:
            day = x[0]

            day_unix = time.mktime(day.timetuple())+float("0.%s"%day.microsecond)

            items.append(AttrDict(x=day_unix, y=x[1] ))

        return items
    
    class Meta:
        key = 'Unique listeners'
        resource_name = 'stats/users/unique-listeners'
        list_allowed_methods = ['get',]

