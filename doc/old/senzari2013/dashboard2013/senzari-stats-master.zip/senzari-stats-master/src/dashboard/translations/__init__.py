from templatetags.trans import TranslationVariable
from django.template import Context

def gettext(message):
    return TranslationVariable(message).resolve(Context({}))

def ugettext(message):
    return u'%s' % gettext(message)
