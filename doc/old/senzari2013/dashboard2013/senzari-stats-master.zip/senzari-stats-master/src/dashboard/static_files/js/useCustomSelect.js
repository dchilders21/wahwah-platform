/* Used this alongside http://adam.co/lab/jquery/customselect/ to provide
 * responsive, custom styled select boxes.
 */

(function() {
  // Custom select boxes
  $(document).ready(function() {
    $('select.customSelect').customSelect();
  });

  // customSelect hides the select box but uses its data to create a span structure.
  // This spanning does not work on a screen resize (e.g. arrow in wrong place,
  // not entirely clickable). So, resetting and running $().customSelect() again
  // on resize is necessary.
  $(window).resize(function() {
    // Set back to default state
    $('span.customSelect').remove();
    $('select.customSelect').attr('style','');

    // Add styling again
    $('select.customSelect').customSelect();
    $('.customSelectInner').css("width", "100%");
  });
}).call(this);
