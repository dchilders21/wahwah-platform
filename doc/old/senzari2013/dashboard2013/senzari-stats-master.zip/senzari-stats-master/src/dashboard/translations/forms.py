
from django import forms

from translations.models import TokenTranslation

class TokenTranslationForm(forms.ModelForm):
    """ Form for token translation """

    def save(self, *args, **kwargs):
        super(TokenTranslationForm, self).save(*args, **kwargs)
