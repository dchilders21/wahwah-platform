import json
import logging

from django.conf import settings
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.db import models
from django.utils.translation import ugettext as _

from ..models.request import make_request

from utils.decorators import classproperty
from utils.fields import JSONField

log = logging.getLogger(__name__)

class RestObjectManager(object):
    """
    The manager class to do the persistence
    for the REST based objects.
    """

    def __init__(self):
        """
        Initialize the values provided by children classes.
        * url_component: Object's id in the api's url, such as 'widget' for '/api/.10/widget/'
        """
        self.url_component = self.get_url_component()

    def get(self, *args, **kwargs):
        """
        """
        params = {}

        if args:
            params['id'] = args[0]
        else:
            params = kwargs


        if 'id' in params and len(params.keys()) == 1:
            data = self._make_request('/api/1.0/{0}/{1}/'.format(self.url_component, params['id']))
        else:
            data = self._make_request('/api/1.0/{0}/'.format(self.url_component), self._normalize_params(params))

        if not data:
            raise ObjectDoesNotExist()

        if isinstance(data, list):
            if len(data) > 1:
                raise MultipleObjectsReturned()

            return self.from_rest_data(**data[0])
        else:
            return self.from_rest_data(**data)

    def from_rest_data(self, **kwargs):
        """
        Utility method to create a object
        based on REST data (after a GET query).
        """
        return None

    def filter(self, **kwargs):
        """
        Filters the widgets based on some criteria
        """

        data = self._make_request('/api/1.0/{0}/'.format(self.url_component), self._normalize_params(kwargs))
        if not data:
            return []

        retval = []
        for d in data:
            retval.append(self.from_rest_data(**d))

        return retval

    def all(self):
        return self.filter()

    def save(self, instance, **kwargs):
        """
        Saves the instance of the widget
        """
        if not instance:
            raise Exception()

        # If the id is 'not assigned' it means we *want* a new one.
        updating = False if instance.id < 0 else self.exists(instance.id)

        if updating:
            method = 'PUT'
            url_part = instance.id
        else:
            method = 'POST'
            url_part = ''

        headers = { 'content-type' : 'application/json' }
        url = '/api/1.0/{0}/{1}/'.format(self.url_component, url_part)
        payload = self._normalize_payload(instance.to_dict())

        data = self._make_request(url, headers=headers, payload=payload, method=method)

        data = data if data else {}
        instance.updated(**data)

    def delete(self, instance):
        """
        Deletes a specific widget.
        """
        if not instance:
            return

        self.delete_by_id(instance.id)
        instance.id = -1

    def delete_by_id(self, id):
        """
        Deletes a widget based on its id.
        """
        if id < 0:
            return

        url = '/api/1.0/{0}/{1}/'.format(self.url_component, id)
        self._make_request(url, method='DELETE')

    def _normalize_payload(self, data):
        """
        Normalizes the object data to the format
        our REST api expects.
        """
        return data

    def exists(self, id):
        """
        Simples way to check an obj exists based on its id.
        Return a boolean value.
        """
        if not isinstance(id, int) or id < 0:
            return False

        data = self._make_request("/api/1.0/{0}/{1}/".format(self.url_component, id))
        return data != None

    def _normalize_params(self, params):
        """
        Pre processes the params passed to the REST api.

        It will fix/patch elements as required, e.g.
            id__in = [1, 3, 5] -> ids = '1,3,5'

        Will leave everything not recognized untouched.
        """

        if 'id__in' in params:
            params['ids'] = ','.join([str(val) for val in params['id__in']])
            del params['id__in']

        return params

    def _make_request(self, url, params=None, payload=None, headers=None, method='GET'):
        return make_request(url.replace('//', '/'), params, payload, headers, method)

class RestObject(object):
    """
    A class to consume the Senzari REST api.
    """
    def __init__(self, **kwargs):
        self.id = int(kwargs.get('id', -1))

    @classmethod
    def from_rest_data(cls, **kwargs):
        """
        Build a new REST object with data retrieved
        using the GET method from the api.
        """
        return None

    @classmethod
    def get_id_from_url(cls, url, null=False):
        """
        Utility method to guess the id component
        for an url.
        """
        if not url and null:
            return None

        if not url and not null:
            raise Exception('The url was not expected to be None.')


        # This is sort of annoying, as we extract the id from
        # a resource, such /api/1.0/websites/1/, where the id
        # is '1'. If we ever retrieve the full field (instead
        # of just the resource url) we can drop this and directly
        # consume the 'id' field there.
        url_len = len(url)
        if url_len == 0:
            raise Exception('The url is empty.')

        # Look for the last digit contained within two slashes,
        # such ../92/
        end = url_len - 1 if url.endswith('/') else url_len
        pos = url.rfind('/', 0, end)

        return int(url[pos + 1:end])

    def to_dict(self):
        """
        Converts the current obj data
        to a dictionary.
        """
        return {}

    def save(self):
        """
        Save or updates the current widget information.
        """
        pass

    def delete(self):
        pass

    def updated(self, **kwargs):
        """
        Object has just been saved using POST/PUT,
        and we receive the data response in case
        we want to look for updated values.
        """
        pass


