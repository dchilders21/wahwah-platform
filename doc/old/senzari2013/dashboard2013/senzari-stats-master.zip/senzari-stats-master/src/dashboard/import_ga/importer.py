
import datetime
import sys
import psycopg2

from django.db import connections

from apiclient.errors import HttpError
from oauth2client.client import AccessTokenRefreshError

import import_auth
from utils.isocountries import *

GA_PROFILEID = '71696199'

def import_data(day):

    print 'Day: %s' % day
    service = import_auth.initialize_service()
    try:
        raw_impressions, raw_by_country = get_impressions(service, GA_PROFILEID, day)
        impressions, by_country = parse_ga_results(raw_impressions.get('rows'), raw_by_country.get('rows'))

        if not impressions:
            print 'Data not (yet) available for this day'
            return

        print 'Injecting values...'
        inject_data(impressions, by_country, day)

    except TypeError as error:
        print ('There was an error constructing your query: %s' % error)
    except HttpError as error:
        print ('There was an API error: %s, %s' % (error, error._get_reason()))
    except AccessTokenRefreshError:
        print ('The crentials have been revoked or expire, please re-run the application to re-authorize')
    except psycopg2.Error as error:
        print ('There was an error injecting data in the backend: %s' % error)

def parse_ga_results(impressions, by_country):
    """
    Receive a list of tuples, containing:
        0 - pagepath (unicode)
        1 - counter value (unicode)
    """
    if not impressions or not by_country:
        return (None, None)

    def extract_id(path):
        values = path.split('/')
        if len(values) != 4: # ['', 'widget', '1', '']
            raise Exception('Unexpected path format: %s' % path)

        return int(values[2])

    def get_country_code(country):
        country = country.upper()
        return ISO3166_REVERSE[country].lower() if country in ISO3166_REVERSE else 'unknown'

    impressions2 = [(extract_id(path), int(value)) for path, value in impressions]
    by_country2 = [(extract_id(path), get_country_code(country), int(value)) for path, country, value in by_country]

    return (impressions2, by_country2)

def get_impressions(service, profile_id, day):
    """
    Return a tuple with the two raw objects returned for
    1. total impressions per widget
    2. total impressions per widget, separated by country

    (We could make a simple call and do the sum ourselves
    for the total value (1), but GA seems to return slightly
    different values...)
    """

    impressions = service.data().ga().get(
        ids = 'ga:' + profile_id,
        start_date = str(day),
        end_date = str(day),
        metrics = 'ga:pageviews',
        dimensions = 'ga:pagepath',
        filters= 'ga:pagePathLevel1==/widget/',
    ).execute()

    impressions_by_country = service.data().ga().get(
        ids = 'ga:' + profile_id,
        start_date = str(day),
        end_date = str(day),
        metrics = 'ga:pageviews',
        dimensions = 'ga:pagepath,ga:country',
        filters= 'ga:pagePathLevel1==/widget/',
    ).execute()

    return (impressions, impressions_by_country)


def inject_data(impressions, by_country, day):
    '''
    impressions - list of tuples containing total impressions per widget.
    by_country - list of tuples containing total impressions per widget/country.
    '''

    connection = connections['stats']
    for imp in impressions:
        id, value = imp
        push_record(connection, id, 'counters.loaded', value, day)

    for imp_country in by_country:
        id, country, value = imp_country
        push_record(connection, id, 'counters.loaded_by_country._{0}'.format(country), value, day)

    connection.connection.commit()

def push_record(connection, id, name, value, day):
    sql = '''
    UPDATE summary_stats SET
        value = %s
    WHERE
        widget_id = %s AND
        name = %s AND
        day = %s
    '''

    print ('Pushing %s - %s = %s' % (id, name, value))
    
    cursor = connection.cursor()

    try:
        cursor.execute(sql, (value, id, name, day))
    except psycopg2.Error as error:
        print ' Inserting it as new record!'

        sql = '''
            INSERT INTO summary_stats(widget_id, name, value, day)
            VALUES(%s, %s, %s, %s)
        '''
        cursor.execute(sql, (id, name, value, day))
    finally:
        cursor.close()

if __name__ == '__main__':
    import_data(sys.argv)

