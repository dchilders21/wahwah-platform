
from datetime import date, timedelta
from django.db import models, connections
from django.utils.translation import ugettext as _
import psycopg2

from .widget_statsdef import *

class WidgetStatCollector(object):

    DefaultPeriodDays = 30
    
    def __init__(self, period_from, period_to):
        pass
        # Raise exception here to prevent us from being created?

    @classmethod
    def get_default_period(cls):
        end_date = date.today()
        from_date = end_date - timedelta(days=cls.DefaultPeriodDays)

        return (from_date, end_date)

    # or should we ourselves create the connection and just fire? depends on how this is
    # consumed from the API code
    @classmethod
    def collect(cls, widget_id, period_from=None, period_to=None, connection=None):
        if not period_from or not period_to:
            period_from, period_to = cls.get_default_period()

        if not connection:
            connection = connections['stats']

        stats = {}
        for stat_key, stat_value in WIDGET_STATS.iteritems():
            if stat_value.is_average:
                querier = AverageQuerier(widget_id, stat_key)
            elif stat_value.is_key_based:
                querier = KeyQuerier(widget_id, stat_key)
            else:
                querier = LinearQuerier(widget_id, stat_key)

            values = querier.query(connection, period_from, period_to)
            stats[stat_key] = values

        return stats

class StatQuerier(object):

    def __init__(self, widget_id, stat):
        self._widget_id_ = widget_id
        self._stat_ = stat

    @property
    def widget_id(self):
        return self._widget_id_

    @property
    def stat(self):
        return self._stat_

    def get_stat_key(self):
        return '{0}._w{1}._'.format(self.stat, self.widget_id)

    def query(self, connection, period_from, period_to):
        pass

class AverageQuerier(StatQuerier):
    def __init__(self, widget_id, stat):
        super(AverageQuerier, self).__init__(widget_id, stat)
        self._averages_ = None

    # We could let it go transparent to the API and include this as
    # 'values' for all our queriers...
    @property
    def averages(self):
        return self._averages_

    def query(self, connection, period_from, period_to):

        sql = """
            SELECT day, COUNT(name), SUM(value), CAST(SUM(value) / COUNT(id) AS INT) AS average
            FROM daily_stats
            WHERE name ~ %s
            AND day >= %s AND day <= %s
            GROUP BY day
            ORDER BY day;
        """
        cursor = connection.cursor()
        cursor.execute("SET TIMEZONE TO 'UTC'") # Use UTC, as we do it in Postgresql for now.

        cursor.execute(sql, (self.get_stat_key(), period_from, period_to))
        data = cursor.fetchall()

        averages = []
        for row in data:
            day = row[0]
            count = row[1]
            stat_sum = row[2]
            average = row[3]

            # I suggest returning them in a way that
            # helps us expose the data in the json format in
            # a DECENTE and correct way.
            averages.append(AveragePoint(day, average, stat_sum, count))

        self._averages_ = averages
        return averages

class AveragePoint(object):
    def __init__(self, day, average, stat_sum, count):
        self.day = day
        self.average = average
        self.stat_sum = stat_sum
        self.count = count

class KeyQuerier(StatQuerier):

    def __init__(self, widget_id, stat):
        super(KeyQuerier, self).__init__(widget_id, stat)
        self._values_ = None

    @property
    def values(self):
        return self._values_

    def query(self, connection, period_from, period_to):
        sql = """
            SELECT name, SUM(value)
            FROM daily_stats
            WHERE name ~ %s
            AND day >= %s AND day <= %s
            GROUP BY name
            ORDER BY name;
        """

        cursor = connection.cursor()
        cursor.execute("SET TIMEZONE TO 'UTC'") # Use UTC, as we do it in Postgresql for now.

        cursor.execute(sql, (self.get_stat_key(), period_from, period_to))
        data = cursor.fetchall()

        values = {}
        for row in data:
            name = row[0]
            stat_sum = row[1]

            param = self._get_stat_param_(name)
            values[param] = stat_sum

        self._values_ = values
        return values

    def _get_stat_param_(self, name):
        tokens = name.split('._')
        if len(tokens) < 3 or len(tokens[2]) == 0:
            return None # Parameter is missing.

        param = tokens[2].strip()
        return param if param != 'undefined' else 'undefined'


class LinearQuerier(StatQuerier):

    def __init__(object, widget_id, stat):
        super(LinearQuerier, self).__init__(widget_id, stat)
        self._values_ = None

    @property
    def values(self):
        return self._values_

    def get_stat_key(self):
        # Override, as we do not use parameters here.
        return '{0}._w{1}'.format(self.stat, self.widget_id)

    def query(self, connection, period_from, period_to):
        sql = """
            SELECT day, value
            FROM daily_stats
            WHERE name ~ %s
            AND day >= %s AND day <= %s
            ORDER BY day;
        """

        cursor = connection.cursor()
        cursor.execute("SET TIMEZONE TO 'UTC'") # Use UTC, as we do it in Postgresql for now.

        cursor.execute(sql, (self.get_stat_key(), period_from, period_to))
        data = cursor.fetchall()

        values = []
        for row in data:
            day = row[0]
            value = row[1]

            values.append((day, value))

        self._values_ = values
        return values


