from django.contrib import admin
from django.forms.models import modelform_factory
from django.utils.functional import curry
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.http import Http404, HttpResponse, HttpResponseRedirect

from translations.forms import TokenTranslationForm
from translations.models import Locale, Environment, Token, TokenTranslation


DEFAULT_CONSOLIDATED_ENVIROMENT = 0

csrf_protect_m = method_decorator(csrf_protect)

class LocaleAdmin(admin.ModelAdmin):
    list_display = ('name', 'locale',)
admin.site.register(Locale, LocaleAdmin)


class EnvironmentAdmin(admin.ModelAdmin):
    pass
admin.site.register(Environment, EnvironmentAdmin)


class TokenAdmin(admin.ModelAdmin):
    pass
admin.site.register(Token, TokenAdmin)


def consolidate(modeladmin, request, queryset):
    """
    Runs through all the locales and generates keys in every environment
    """
    created_counter = 0
    environment = Environment.objects.get(order=DEFAULT_CONSOLIDATED_ENVIROMENT)
    tokens = Token.objects.all()
    locales = Locale.objects.exclude(locale__iexact='en')

    for token in tokens:
        for locale in locales:
            kwargs = {}
            kwargs['environment'] = environment
            kwargs['token'] = token
            kwargs['locale'] = locale
            kwargs['defaults'] = {}
            (token_translation, created) = TokenTranslation.objects.get_or_create(**kwargs)

            if created:
                created_counter += 1

    modeladmin.message_user(request, "%s token translations successfully created." % created_counter)

enviroment = Environment.objects.get(order=DEFAULT_CONSOLIDATED_ENVIROMENT).name
consolidate.short_description = "Generate tokens for every locale in " + enviroment

def migrate(modeladmin, request, queryset):
    """
    Migrates tokens to their next respective environments.

    """

    for token in queryset.all():

        try:
            next_environment = Environment.objects.get(order=(token.environment.order+1))

            kwargs = {}
            kwargs['environment'] = next_environment
            kwargs['token'] = token.token
            kwargs['locale'] = token.locale
            kwargs['defaults'] = { 'value': token.value, 'modified_by': token.modified_by }
            (migrated_token, created) = TokenTranslation.objects.get_or_create(**kwargs)

            if not created:
                migrated_token.value = token.value
                migrated_token.modified_by = token.modified_by
                migrated_token.save()

        except Environment.DoesNotExist:
            pass

        # Set this token to has_migrated = True so we can 
        # keep track of tokens that have changed and need migrations,
        # and tokens that have not changed and do not need to be migrated.
        token.save(has_migrated=True)

migrate.short_description = "Migrates the tokens to the next environment"


class TokenTranslationAdmin(admin.ModelAdmin):
    list_display = ('admin_name', 'value', 'english_value', 'environment_name', 'locale_name')
    list_filter = ('has_translation', 'has_migrated', 'environment__name', 'locale__name', 'modified_date', 'modified_by')
    search_fields = ('token__key', 'value')
    list_editable = ('value',)
    actions = [migrate, consolidate,]

    @csrf_protect_m
    def changelist_view(self, request, extra_context=None):
        if request.method == 'POST':
            data = request.POST.copy()
            action = data.get('action')

            if action == 'consolidate':
                ChangeList = self.get_changelist(request)
                cl = ChangeList(
                    request, self.model, list(self.list_display), self.list_display_links,
                    self.list_filter, self.date_hierarchy, self.search_fields,
                    self.list_select_related, self.list_per_page, self.list_editable, self
                )

                queryset = cl.get_query_set()

                func, name, description = self.get_actions(request)[action]
                response = func(self, request, queryset)

                # Actions may return an HttpResponse, which will be used as the
                # response from the POST. If not, we'll be a good little HTTP
                # citizen and redirect back to the changelist page.
                if isinstance(response, HttpResponse):
                    return response
                else:
                    return HttpResponseRedirect(request.get_full_path())

        return super(TokenTranslationAdmin, self).changelist_view(request, extra_context)

    def get_actions(self, request):
        actions = super(TokenTranslationAdmin, self).get_actions(request)
        del actions['delete_selected']
        return actions

    def save_model(self, request, obj, form, change):
        form.instance.modified_by = u' '.join([request.user.first_name, request.user.last_name])
        super(TokenTranslationAdmin, self).save_model(request, obj, form, change)

admin.site.register(TokenTranslation, TokenTranslationAdmin)
