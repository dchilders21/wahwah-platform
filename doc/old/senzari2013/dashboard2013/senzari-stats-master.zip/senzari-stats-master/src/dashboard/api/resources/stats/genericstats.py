import logging
import simplejson
import time

from django.db import connections
from django.conf.urls.defaults import *
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.core.urlresolvers import reverse

from tastypie import fields
from tastypie.exceptions import ImmediateHttpResponse
from tastypie.http import HttpUnauthorized, HttpBadRequest, HttpForbidden
from tastypie.resources import ALL_WITH_RELATIONS
from tastypie.utils import trailing_slash

from ..base import AttrDict, StatsResource, DjangoAuthentication

log = logging.getLogger(__name__)  # Get an instance of a logger

class GenericStatsResource(StatsResource):
    """ Generic stats resource (carbon bacend) """

    def override_urls(self):
        return [
                url(r"^(?P<resource_name>%s)%s$" % (self._meta.resource_name,
                                                    trailing_slash()),
                    self.wrap_view('dispatch_list'), name="generic_stat_list"),
            ]

    def normalize_stat_name(self, name):
        if len(name) == 0:
            ''' A default metric '''
            return 'stats.counters.statsd.packets_received'

        return 'stats.counters.%s' % name

    def get_values(self, request, **kwargs):
        cursor = connections['stats'].cursor()
        sql = """
            SELECT day, value
            FROM daily_stats
            WHERE name=%s
            AND day > %s AND day < %s
        """

        name = self.normalize_stat_name(request.GET.get('name', ''))
        start = self.parse_date(request.GET.get('start', ''))
        end = self.parse_date(request.GET.get('end', ''))
        if not start: start = self.default_start_date
        if not end: end = self.default_end_date

        cursor.execute(sql, [name, start, end])
        data = cursor.fetchall()

        items = []
        for x in data:
            day = x[0]

            day_unix = time.mktime(day.timetuple())+float("0.%s"%day.microsecond)

            items.append(AttrDict(x=day_unix, y=x[1] ))
        return items

    class Meta:
        key = 'Generic stats info'
        resource_name = 'stats/generic-stat-item'
        list_allowed_methods = ['get',]

