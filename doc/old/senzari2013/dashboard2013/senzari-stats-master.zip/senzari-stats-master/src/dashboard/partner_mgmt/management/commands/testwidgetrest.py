
from django.core.management.base import BaseCommand, CommandError

from unittest2 import *
import partner_mgmt.tests

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        tests = defaultTestLoader.loadTestsFromModule(partner_mgmt.tests)
        TextTestRunner().run(tests)

