
from datetime import date, timedelta

from django.db import models, connections
from django.utils.translation import ugettext as _

class StatsItem(object):
    def __init__(self, name, date, value, param=None):
        self.key = name
        self.date = date
        self.value = value
        self.param = param # In case the stats includes an extra param.

    def __repr__(self):
        return self.__unicode__()

    def __unicode__(self):
        return u'({0}) {1} : {2} = {3}'.format(self.key, self.param, self.date, self.value)

class WidgetStatsBase(object):
    """
    Contains all the stats information
    for a widget.
    """
    DefaultPeriodDays = 30

    def __init__(self, *args, **kwargs):
        self.widget = kwargs['widget']
        self.period_from = None
        self.period_to = None
        self.data = None

    def set_period(self, period_from, period_to):
        """
        Sets the period the stats. If not set,
        we use the default one.
        """
        self.period_from = period_from
        self.period_to = period_to

        # Clear out data since period has presumably changed
        self.data = {}

    def get_default_period(self):
        end_date = date.today()
        from_date = end_date - timedelta(days=WidgetStatsBase.DefaultPeriodDays)

        return (from_date, end_date)

    def get_allkeys_regex(self):
        # Postgres's SIMILAR TO, which uses a regex alike syntax.
        # Counters can have an appended extra value, as in loaded_by_cuntry.w_123._us
        names = []
        for key, value in WIDGET_STATS.items():
            if value.has_parameter:
                str = '{0}\._w{1}\._'
            else:
                str = '{0}\._w{1}$'

            name = str.format(key, self.widget.id)
            names.append(name)

        keys = "'{0}'".format("|".join(names))
        return keys

    def _get_data(self):
        if not self.period_from or not self.period_to:
            self.period_from, self.period_to = self.get_default_period()

        if not self.data:
            cursor = connections['stats'].cursor()
            self.data = self._process_query_(cursor)

        return self.data

    def _process_query_(self, cursor):
        return None

class WidgetStats(WidgetStatsBase):
    def __init__(self, **kwargs):
        super(WidgetStats, self).__init__(**kwargs)

        # Cached data
        self._loaded_by_country = None
        self._station_plays = None
        self._radio_plays = None

        # Cache the keys.
        self.keys = WIDGET_STATS.keys()

    @property
    def loaded(self):
        return self._get('counters.loaded')

    @property
    def loaded_by_country(self):
        if not self._loaded_by_country:
            data = self._get('counters.loaded_by_country')
            self._loaded_by_country = self._map_values(data)

        return self._loaded_by_country

    @property
    def station_plays(self):
        if not self._station_plays:
            data = self._get('counters.stations.plays')
            self._station_plays = self._map_values(data)

        return self._station_plays

    @property
    def radio_plays(self):
        if not self._radio_plays:
            data = self._get('counters.initiated')
            self._radio_plays = self._map_values(data, include_date=True)

            # Make space for explicit parameters, if none.
            for param in WIDGET_STATS['counters.initiated'].parameters:
                if not param in self._radio_plays:
                    self._radio_plays[param] = []

        return self._radio_plays

    @property
    def onsite_time(self):
        return self._get('counters.site.time')

    @property
    def streaming_time(self):
        return self._get('timers.streaming.time')

    def _map_values(self, values, include_date=False):
        data = {}
        for value in values:
            if not value.param:
                continue # Ignore incomplete data.

            key = value.param
            if not key in data:
                data[key] = []

            if include_date:
                # Rip time off.
                data[key].append((value.date.date(), value.value))
            else:
                data[key].append(value.value)

        return data

    def get_loaded_by_country(self, country_code):
        return [stat for stat in self._get('counters.loaded_by_country') if stat.param == country_code]

    def _get(self, counter):
        if not self.data:
            self._get_data()

        return self.data[counter]

    # TODO Lets improve this one.
    def _get_counter_key(self, value):
        for key in self.keys:
            if value.startswith(key):
                return key

        return None

    def _process_query_(self, cursor):
        keys = self.get_allkeys_regex()

        sql = """
            SELECT
                s.name,
                s.day,
                s.value
            FROM daily_stats s
            WHERE s.day >= %s
            AND s.day <= %s
            AND s.name ~ {0}
            ORDER BY s.day
        """.format(keys)

        # Use UTC, as we do it in Postgresql for now.
        cursor.execute("SET TIMEZONE TO 'UTC'")

        cursor.execute(sql, (self.period_from, self.period_to))
        data = cursor.fetchall()

        stats_data = {}
        for key in WIDGET_STATS.keys():
            stats_data[key] = []

        # We could save the very original counter name
        # instead of 'key', and use it to slice
        # the counters on request for loaded_by_country
        # and radio plays.
        for row in data:
            key = self._get_counter_key(row[0])

            param = None
            if WIDGET_STATS[key].has_parameter:
                tokens = row[0].split('._')
                if len(tokens) < 3 or len(tokens[2]) == 0:
                    continue # Parameter is missing.

                param = tokens[2].strip()
                if param == 'undefined':
                    continue

            tstamp = row[1]
            value = row[2]
            stat = StatsItem(key, tstamp, value, param=param)
            stats_data[key].append(stat)

        return stats_data


