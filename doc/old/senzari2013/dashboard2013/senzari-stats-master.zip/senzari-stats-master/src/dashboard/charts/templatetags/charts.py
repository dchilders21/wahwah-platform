import copy
from datetime import date

from django.template import Library
from django.utils.datastructures import SortedDict
from django.core.urlresolvers import reverse
from django.utils.safestring import SafeUnicode, SafeString


register = Library()


@register.filter(name='get_type_url')
def get_type_url(chart, chart_type):
    return chart.get_url('type', chart_type)

@register.filter(name='get_period_url')
def get_period_url(chart, period_type):
    return chart.get_url('period', period_type)

