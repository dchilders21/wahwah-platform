import logging

from django.conf import settings
from django.contrib.auth.models import User
from django.core.cache import cache, get_cache
from django.db import models
from django.db.models import Q
from django.db.models.signals import post_save, pre_delete
from django.template.defaultfilters import slugify
from django.template import resolve_variable
from django.utils.encoding import smart_str
from django.utils.http import urlquote
from django.utils.hashcompat import md5_constructor
from django.utils.translation import ugettext_lazy as _


log = logging.getLogger(__name__)  # Get an instance of a logger

ENVIRONMENT = getattr(settings, 'ENVIRONMENT', 'dev')
DEFAULT_LOCALE = getattr(settings, 'LANGUAGE_CODE',)
GET_TRANSLATION_TOKENS_SECONDS = getattr(settings, 'GET_TRANSLATION_TOKENS_SECONDS')
CACHES = getattr(settings, 'CACHES', {})
RUNNING_LOCALLY = getattr(settings, 'RUNNING_LOCALLY', False)
TRANSLATION_CACHE_PREFIX = getattr(settings, 'TRANSLATION_CACHE_PREFIX', None)

class TokenKey(object):
    """
    This object represents a token key.

    In short, we need a standardized way to get at a few different types
    of values:

    >>> key = TokenKey('featured.stations.title', environment='DEV', locale='en-US')
    >>> print key.cache_key
    u'dev:en-us:featured.stations.title'
    >>> print key.token_key
    u'featured.stations.title'
    """

    def __init__(self, value, environment=ENVIRONMENT, locale=DEFAULT_LOCALE):
        # Performs some basic validations to ensure that the key wont
        # get too long.

        self._base_key = None

        if isinstance(value, TokenTranslation):
            self.value = value.token.key
            self.environment = value.environment.name
            self.locale = value.locale.locale

        else:
            if len(environment) > 4:
                raise Exception('the ENVIRONMENT variable cannot exceed 4 chars.')

            if len(locale) > 5:
                raise Exception('the locale variable cannot exceed 5 chars.')

            self.value = value
            self.environment = environment
            self.locale = locale


    @property
    def base_key(self):
        """ Returns the base key """
        if not self._base_key:
            # Memcache wont allow spaces, or line breaks.
            value = self.value.replace(u' ', u'_').replace(u'\n', u'')
            key = smart_str(value)

            # Also has a limit of 250 chars... We leave 11 characters
            # out to save for extra prefix characters.
            if len(key) <= 240:
                self._base_key = key
            else:
                # Hash the value but maintain some readability.
                self._base_key = key[:210] + u'.trunc.' + hash(key[210:])

        return self._base_key

    @property
    def cache_key(self):
        args = [self.environment.lower(), self.locale, self.base_key]
        if TRANSLATION_CACHE_PREFIX:
            args.insert(0, TRANSLATION_CACHE_PREFIX)
        return ':'.join(args)

    @property
    def token_key(self):
        return self.base_key


class Locale(models.Model):
    """ Locale """

    name = models.CharField(_('name'), max_length=50, editable=False, help_text='Country name ie. \'United States\' or \'Spain\'')
    locale = models.CharField(_('code'), max_length=2, db_index=True, help_text='Country code ie. \'US\' or \'SP\'')

    def __unicode__(self):
        return u'{model.name} [{model.locale}]'.format(model=self)

    def save(self, force_insert=False, force_update=False, using=None):
        self.locale = self.locale.lower()[:2]
        super(Locale, self).save(force_insert=force_insert, force_update=force_update, using=using)


class Environment(models.Model):
    """ An environment """

    name = models.CharField(_('environment name'), max_length=20, editable=False, db_index=True, unique=True)
    order = models.IntegerField(_('order'), default=0)

    def __unicode__(self):
        return u'%s' % self.name.title()


class Token(models.Model):
    """ A translation token """

    key = models.CharField(_('key'), max_length=250, db_index=True, unique=True)

    def __unicode__(self):
        return u'%s' % self.key


class TokenTranslationManager(models.Manager):

    def get_query_set(self):
        """
        Override the queryset so it does not return any deleted records
        """

        uber = super(TokenTranslationManager, self)
        return uber.get_query_set().select_related('token__key', 'environment__name', 'locale__locale')


class TokenTranslation(models.Model):
    """ A translation """

    token = models.ForeignKey(Token, verbose_name=_('token'), related_name='translations')
    locale = models.ForeignKey(Locale, verbose_name=_('locale'))
    environment = models.ForeignKey(Environment, verbose_name=_('environment'), related_name='translations')
    value = models.TextField(_('value'), max_length=2000, null=True, blank=True)
    has_translation = models.BooleanField(_('has translation'), default=False, editable=False)
    has_migrated = models.BooleanField(_('has been migrated'), default=False, editable=False)
    modified_date = models.DateTimeField(_('modified date'), auto_now=True, null=True)
    modified_by = models.CharField(_('modified by'), max_length=255, editable=False, blank=True, default='')

    objects = TokenTranslationManager()

    def _expire_template_cache_key(self, fragment_name, vary_on):
        #
        # This code is basically a mod of the cache template tag; ln 27-28 in
        # https://github.com/django/django/blob/1.3.X/django/templatetags/cache.py
        #
        args = md5_constructor(u':'.join([urlquote(var) for var in vary_on]))
        key = 'template.cache.%s.%s' % (fragment_name, args.hexdigest())
        log.debug('CACHE: deleting %s from %s' % (key, self.environment.name))

        c = cache if self.environment.name not in CACHES else get_cache(self.environment.name)
        c.delete(key)

        if RUNNING_LOCALLY and self.environment.name == 'dev':
            log.debug('CACHE: deleting local cache too %s from %s' % (key, self.environment.name))
            c = get_cache('default')
            c.delete(key)

    def save(self, force_insert=False, force_update=False, using=None, has_migrated=False):
        # Invalidate cache when object is changed.
        key = TokenKey(self)

        c = get_cache('prod')
        c.delete(key.cache_key)

        if RUNNING_LOCALLY and self.environment.name == 'dev':
            local_c = get_cache('default')
            local_c.delete(key.cache_key)

        log.debug(u'CACHE: deleting %s' % key.cache_key)

        # Like... Magic! We also need to expire cache for fragment caches.
        #
        # template.cache.localization_tokens.9cfefed8fb9497baa5cd519d7d2bb5d7
        # template.cache.js_templates.9cfefed8fb9497baa5cd519d7d2bb5d7
        #
        vary_on = [self.locale.locale]
        self._expire_template_cache_key('localization_tokens', vary_on)
        self._expire_template_cache_key('js_templates', vary_on)

        self.has_translation = True if self.value else False


        # Since the record was now saved, the has_migrated has to be
        # set to false, unless the environment is prod, then its always
        # true, since you cant migrate it anymore from production.
        self.has_migrated = has_migrated if self.environment.name != 'prod' else True

        log.debug('DB: %s set has_migrated to %s' % (key.cache_key, has_migrated))


        super(TokenTranslation, self).save(force_insert=force_insert, force_update=force_update, using=using)

        # Update has_changed = False on all tokens in higher environments,
        # since somebody now changed this token.

        # Next, back-propagate the values to environments
        # that might be missing the value.
        try:
            # Only back propagate if there is a value to
            # avoid wiping data out.
            if self.value:
                prev_environment = Environment.objects.get(order=(self.environment.order - 1))
                (prev_env_token, created) = TokenTranslation.objects.get_or_create(environment=prev_environment, \
                        token=self.token, \
                        locale=self.locale, \
                        defaults={ 'value': self.value, \
                                   'modified_by': self.modified_by, \
                                   'has_migrated': True })

                if not created and prev_env_token.value != self.value:
                    prev_env_token.value = self.value
                    prev_env_token.modified_by = self.modified_by
                    prev_env_token.save(has_migrated = True)

        except Environment.DoesNotExist:
            pass


    @property
    def english_value(self):
        """ The english translation for this value. """

        key = TokenKey(self)
        key.locale = 'en'

        # attempt to get from cache to avoid n+1 select
        value = cache.get(key.cache_key)

        if not value:
            try:
                kwargs = {}
                kwargs['token__key'] = key.value
                kwargs['environment__name'] = key.environment
                kwargs['locale__locale'] = key.locale
                token = TokenTranslation.objects.get(**kwargs)
                value = token.value or token.token.key
                log.debug(u'DB: getting %s' % key.cache_key)
                cache.set(key.cache_key, value, GET_TRANSLATION_TOKENS_SECONDS)

            except TokenTranslation.DoesNotExist:
                value = ''
        else:
            log.debug(u'CACHE: %s' % key.cache_key)

        return value


    @property
    def name(self):
        return u':'.join([self.environment.name, self.locale.locale, self.token.key])

    def admin_name(self):
        """ admin_order_field does not work on properties.. cant break the code. """
        return self.name
    admin_name.admin_order_field = 'token__key'

    @property
    def environment_name(self):
        return self.environment.name

    @property
    def locale_name(self):
        return self.locale.locale

    @property
    def token_key(self):
        return self.token.key

    def __unicode__(self):
        return self.name

    class Meta:
        unique_together = ('token', 'locale', 'environment')
