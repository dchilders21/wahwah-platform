import hashlib

from django.core.management.base import BaseCommand, CommandError

from auth.models import Profile
from partner_mgmt.models import User, Widget, Partner, WidgetUser

class Command(BaseCommand):

    def handle(self, *args, **kwargs):
        super_user = User.objects.get(id=16)

        for widget in Widget.objects.all():
            if not (widget.partner and widget.partner.contact_email):
                continue

            partner = widget.partner
            email = partner.contact_email.lower()

            username = hashlib.md5(email).hexdigest()[:30]
            try:
                user, created = User.objects.get_or_create(email=email, defaults={ "username": username })
            except User.MultipleObjectsReturned as exc:
                print 'User %s detected more than one time, skipping.' % email
                continue

            if created:
                print "%s was created for widget id %s" % (username, widget.id)
                user.set_password('password123')
                user.save()

            try:
                wuser, created = WidgetUser.objects.get_or_create(widget_id=widget.id, email=email)
            except WidgetUser.MultipleObjectsReturned as exc:
                print 'WidgetUser %s-%s detected more than one time, skipping.' % (widget.id, email)
                continue

            if created:
                wuser.user = user
                wuser.role = 'owner'
                wuser.save()

            try:
                profile, created = Profile.objects.get_or_create(user__email=email)
            except User.DoesNotExist:
                profile = Profile.objects.create(user=user)
                created = True

            if created:
                profile.first_name = user.first_name
                profile.last_name = user.last_name
                profile.activate()
                profile.save()

            # create superuser
            try:
                wuser, created = WidgetUser.objects.get_or_create(widget_id=widget.id, user=super_user)
            except WidgetUser.MultipleObjectsReturned as exc:
                print 'Superuser for %s-%s detected more than one time, skipping.' % (widget.id, super_user)
                continue

            if created:
                print "superuser was created for widget id %s" % (widget.id)
                wuser.role = 'owner'
                wuser.save()
