
from datetime import date, timedelta

from django.db import models, connections
from django.utils.translation import ugettext as _

from .stats import *

class WidgetStatDefinition(object):
    '''
    Meta-data alike class to contain information
    about the stats, and later be consumed by
    any of our backends.
    '''

    def __init__(self, **kwargs):
        self.name = kwargs.get('name')
        self.has_parameter = kwargs.get('has_parameter', False)
        self.is_average = kwargs.get('is_average', False)
        self.is_key_based = kwargs.get('is_key_based', False)
        self.is_implicit = kwargs.get('is_implicit', False) # Infered from other stats

    def __unicode__(self):
        return u'{0}'.format(self.name)


WIDGET_STATS = {
    'counters.loaded_by_country': WidgetStatDefinition(
        name = 'Bar Impressions by country',
        has_parameter = True,
        is_key_based = True
    ),
    'counters.loaded': WidgetStatDefinition(
        name = 'Bar Impressions',
    ),
    'counters.stations.plays': WidgetStatDefinition(
        name = 'Station Plays',
        has_parameter = True,
        is_key_based = True
    ),
    'counters.site.time': WidgetStatDefinition(
        name = 'On Site Time',
        has_parameter = True,
        is_average = True
    ),
    'counters.site.time.total': WidgetStatDefinition(
        name = 'On Site Time Unique Users',
        is_implicit = True
    ),
    'counters.streaming.time': WidgetStatDefinition(
        name = 'Streaming Time',
        has_parameter = True,
        is_average = True
    ),
    'counters.streaming.time.total': WidgetStatDefinition(
        name = 'Streaming Time Unique Listeners',
        is_implicit = True
    )
}

class WidgetStatsCollector(object):

    DefaultPeriodDays = 30

    _current_ = None # our singleton-alike collector klass.
    
    def __init__(self, **kwargs):
        self.widget_id = kwargs.get('widget_id')
        self.period_from = kwargs.get('period_from', None)
        self.period_to = kwargs.get('period_to', None)
        self.connection = kwargs.get('connection', None)

    @classmethod
    def get_default_period(cls):
        end_date = date.today()
        from_date = end_date - timedelta(days=cls.DefaultPeriodDays)

        return (from_date, end_date)

    @classmethod
    def _get_default_collector(cls):
        return SummaryStatsCollector

    @classmethod
    def collect_stats(cls, **kwargs):
        klass = cls._get_default_collector()
        collector = klass(**kwargs)
        return collector.collect()

    def collect(self):
        '''
        Actual collection of stats. In this base method
        we set up some details for all the child operations.
        '''
        if not self.period_from or not self.period_to:
            self.period_from, self.period_to = WidgetStatsCollector.get_default_period()

        if not self.connection:
            self.connection = connections['stats']

class SummaryStatsCollector(WidgetStatsCollector):

    def __init__(self, **kwargs):
        super(SummaryStatsCollector, self).__init__(**kwargs)

    def collect(self):
        super(SummaryStatsCollector, self).collect()

        date_range = [self.period_from, self.period_to]

        site_stats = SiteStat.objects.filter(widget_id=self.widget_id, day__range=date_range).order_by('day')
        country_stats = CountryStat.objects.filter(widget_id=self.widget_id, day__range=date_range)
        station_stats = StationStat.objects.filter(widget_id=self.widget_id, day__range=date_range)

        loaded = [(str(value.day), value.loaded) for value in site_stats]
        onsite_time = [(str(value.day), value.site_time_average) for value in site_stats]
        onsite_time_count = [(str(value.day), value.site_time_count) for value in site_stats]
        streaming_time = [(str(value.day), value.streaming_time_average) for value in site_stats]
        streaming_time_count = [(str(value.day), value.streaming_time_count) for value in site_stats]
        loaded_by_country = self._group_by_key_(country_stats, lambda x: x.country)
        stations = self._group_by_key_(station_stats, lambda x: x.station_name)

        return dict(
            loaded = loaded,
            onsite_time = onsite_time,
            onsite_time_count = onsite_time_count,
            streaming_time = streaming_time,
            streaming_time_count = streaming_time_count,
            loaded_by_country = loaded_by_country,
            stations = stations,
        )

    def _group_by_key_(self, data, field_key):
        grouped = {}
        for row in data:
            key = field_key(row)
            if key not in grouped:
                grouped[key] = row.value
            else:
                grouped[key] = grouped[key] + row.value

        return grouped

class DailyStatsCollector(WidgetStatsCollector):

    def __init__(self, **kwargs):
        super(DailyStatsCollector, self).__init__(**kwargs)

    def collect(self):
        super(DailyStatsCollector, self).collect()

        stats = {}
        for stat_key, stat_value in WIDGET_STATS.iteritems():
            if stat_value.is_average:
                querier = AverageQuerier(widget_id, stat_key)
            elif stat_value.is_key_based:
                querier = KeyQuerier(widget_id, stat_key)
            else:
                querier = LinearQuerier(widget_id, stat_key)

            values = querier.query(connection, period_from, period_to)
            stats[stat_key] = values

        return stats

