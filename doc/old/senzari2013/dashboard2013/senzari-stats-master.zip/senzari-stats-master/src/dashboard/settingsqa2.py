ENVIRONMENT = 'qa'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'dashboard_qa',
        'USER': 'dashboard_qa',
        'PASSWORD': 'fhasd83jasdfl',
        'HOST': 'localhost',
        'PORT': '',
    },
    'translations': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'dashboard_translations',
        'USER': 'dashboardtrans_prod_usr',
        'PASSWORD': '/(E<{Xm|}1uY![I5E.6k',
        'HOST': 'localhost',
        'PORT': '',
    },
}

MONGODB_HOST = 'localhost'
MONGODB_PORT = 27017
MONGODB_NAME = 'senzari'

SENTRY_DNS = 'https://5e4278c33a5144b3a63c56cda713fc13:c0727c27a8004b89af303bca1381ff10@app.getsentry.com/10513'

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    },
    'prod': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    },
    'qa': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    },
    'dev': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    },
}

# Adding logs
LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(message)s'
        },
    },
    'handlers': {
        'sentry': {
            'level': 'ERROR',
            'class': 'raven.contrib.django.handlers.SentryHandler',
        },
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'verbose'
        },
        'null': {
            'level':'DEBUG',
            'class':'django.utils.log.NullHandler',
        },
    },
    'loggers': {
        'analytics': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'api': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'auth': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'charts': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'core': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'lib': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'translations': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        },
        'utils': {
            'handlers': ['console', 'sentry'],
            'propagate': False,
        }
    },
    'root': {
        # don't put handlers here because you'll get duplicates, only handle
        # on a per-module basis.
        'level': 'WARNING',
    }
}

# Change this secret key for each environment.
SECRET_KEY = 'z+@xf!gwjjclm$z1hhi!@p@46f6yn_c)t+)_zpx8zo$#(v$n(l'

BASE_URL = 'http://dashboard-qa.senzari.com'
MEDIA_URL = '{0}/media/'.format(BASE_URL)

#
# Email settings
#
EMAIL_HOST = 'smtp.sendgrid.net'
EMAIL_PORT = '587'
EMAIL_HOST_USER = 'promail'
EMAIL_HOST_PASSWORD = 'promailrul3s'
EMAIL_USE_TLS = True
SERVER_EMAIL = 'noreply@wahwah.co'


AWS_ACCESS_KEY_ID = 'AKIAICSJX2ASO7ROLBKA'
AWS_SECRET_ACCESS_KEY = '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'

#
# Admin settings
#
ADMINS = (
    (EMAIL_HOST_USER, EMAIL_HOST_USER),
)
MANAGERS = ADMINS


