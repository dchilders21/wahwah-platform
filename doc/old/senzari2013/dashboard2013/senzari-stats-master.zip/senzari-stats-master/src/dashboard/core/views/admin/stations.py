#coding=utf-8

from django import http
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.core import serializers
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect, QueryDict
from django.shortcuts import render_to_response, get_object_or_404
from django.views.decorators.cache import never_cache
from django.utils.translation import ugettext_lazy, ugettext as _
from django.views.decorators.cache import cache_page
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.template import RequestContext

from charts.models import Chart

WIDGET_BASE_URL = getattr(settings, 'WIDGET_BASE_URL')

@login_required
def station_metrics(request):

    chart_sources = [
        WIDGET_BASE_URL + '/api/1.0/stats/stations/played/?format=json',
        WIDGET_BASE_URL + '/api/1.0/stats/stations/created/?format=json',
    ]

    chart = Chart(request, sources=chart_sources)

    return render_to_response('analytics/stations/metrics.html', {
        'chart': chart
    }, RequestContext(request))


