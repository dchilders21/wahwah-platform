from widgets import (widget_index, widget_add, widget_edit,
    widget_manage_users, widget_player_edit, widget_users, widget_view,
    widget_code, widget_revenue, widget_wordpress_plugin)
