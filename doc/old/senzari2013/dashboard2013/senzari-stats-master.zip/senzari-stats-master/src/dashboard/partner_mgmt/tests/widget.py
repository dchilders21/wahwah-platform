import unittest2

from partner_mgmt.models.widget import Widget

class WidgetTest(unittest2.TestCase):
    def setUp(self):
        data = {
            "position" : u"bottomleft",
            "language" : u"en",
            "is_active" : True,
            "website_id" : 1,
            "site_name" : "Monkey Town",
            "site_url" : "http://bananorama.com",
            "analytics_id" : "one_key"
        }
        self.w = Widget(**data)

        self.w2 = Widget()
        self.w2.position = u"bottomright"
        self.w2.language = u"es"
        self.w2.is_active = False
        self.w2.website_id = 2
        self.w2.site_name = "Monkey Parade"
        self.w2.site_url = "http://monkeyparade.com"
        self.w2.analytics_id = "two_key"

        self.default_meta = {
            "artists" : [],
            "stations" : [],
            "monthly_unique_listeners" : ''
        }

    def _copy_widget(self, widget):
        return Widget(**widget.to_dict())

    def test_default_values(self):
        w = Widget()

        self.assertEqual(u"bottomleft", w.position)
        self.assertEqual(True, w.is_active)
        self.assertEqual(None, w.language)
        self.assertEqual(None, w.website_id)
        self.assertEqual(None, w.client_id)
        self.assertEqual(None, w.initial_station_id)
        self.assertEqual(None, w.site_name)
        self.assertEqual(None, w.site_url)
        self.assertEqual(None, w.analytics_id)
        self.assertEqual(self.default_meta, w.meta)

    def test_basic(self):
        w = self.w
        w2 = self.w2

        self.assertEqual(u"bottomleft", w.position)
        self.assertEqual(True, w.is_active)
        self.assertEqual(u"en", w.language)
        self.assertEqual(1, w.website_id)
        self.assertEqual(None, w.client_id)
        self.assertEqual(None, w.initial_station_id)
        self.assertEqual("one_key", w.analytics_id)
        self.assertEqual("Monkey Town", w.site_name)
        self.assertEqual("http://bananorama.com", w.site_url)
        self.assertEqual(self.default_meta, w.meta)

        self.assertEqual(u"bottomright", w2.position)
        self.assertEqual(False, w2.is_active)
        self.assertEqual(u"es", w2.language)
        self.assertEqual(2, w2.website_id)
        self.assertEqual(None, w2.client_id)
        self.assertEqual(None, w2.initial_station_id)
        self.assertEqual("two_key", w2.analytics_id)
        self.assertEqual("Monkey Parade", w2.site_name)
        self.assertEqual("http://monkeyparade.com", w2.site_url)
        self.assertEqual(self.default_meta, w2.meta)

    def test_save(self):
        w = self._copy_widget(self.w)
        w2 = self._copy_widget(self.w2)

        w.save()
        w2.save()

        self.assertTrue(w.id > -1)
        self.assertTrue(w2.id > -1)
        self.assertTrue(w.client_id > -1)
        self.assertTrue(w2.client_id > -1)

        w = Widget.objects.get(w.id)
        w2 = Widget.objects.get(w2.id)

        self.assertTrue(w != None)
        self.assertTrue(w2 != None)

        self.assertEqual

        self.assertEqual(u"bottomleft", w.position)
        self.assertEqual(True, w.is_active)
        self.assertEqual(u"en", w.language)
        self.assertEqual(1, w.website_id)
        self.assertEqual(None, w.initial_station_id)
        self.assertEqual("one_key", w.analytics_id)
        self.assertEqual("Monkey Town", w.site_name)
        self.assertEqual("http://bananorama.com", w.site_url)
        self.assertEqual(self.default_meta, w.meta)

        self.assertEqual(u"bottomright", w2.position)
        self.assertEqual(False, w2.is_active)
        self.assertEqual(u"es", w2.language)
        self.assertEqual(2, w2.website_id)
        self.assertEqual(None, w2.initial_station_id)
        self.assertEqual("two_key", w2.analytics_id)
        self.assertEqual("Monkey Parade", w2.site_name)
        self.assertEqual("http://monkeyparade.com", w2.site_url)
        self.assertEqual(self.default_meta, w2.meta)

        # client_id is a special case: a new client is
        # automatically created when the widget is added.
        self.assertTrue(w.client_id >= 0)
        self.assertTrue(w2.client_id >= 0)

        # Clean up.
        w.delete()
        w2.delete()

    def test_save_minimum(self):
        w = Widget(website_id=1)
        w.site_name = "Banana Republic"
        w.site_url = "http://bananarepublic.com"

        w.save()
        self.assertTrue(w.id >= 0)
        self.assertTrue(w.client_id > 0)

        # Clean up.
        w.delete()

    def test_save_incomplete(self):

        # website, site name and url are missing.
        w = Widget()
        try:
            w.save()
            self.fail("#A1")
        except:
            pass

        # website is set, but site_name and site_url not.
        w = Widget()
        w.website_id = 1
        try:
            w.save()
            self.fail("#A2")
        except:
            pass

        # site_name and site_url are set, but website not
        w = Widget()
        w.site_name = "Hello"
        w.site_url = "http;//hello.com"
        try:
            w.save()
            self.fail("#A3")
        except:
            pass

    def test_update(self):
        w = self._copy_widget(self.w)
        w.save()
        id = w.id
        self.assertTrue(id >= 0)

        w.position = u"bottomright"
        w.is_active = False
        w.language = u"fr"
        w.website_id = 2
        w.site_name = "Ape Town"
        w.site_url = "http://apetown.com"
        w.save()
        self.assertEqual(id, w.id)

        w = Widget.objects.get(w.id)
        self.assertEqual(u"bottomright", w.position)
        self.assertEqual(False, w.is_active)
        self.assertEqual(u"fr", w.language)
        self.assertEqual(2, w.website_id)
        self.assertEqual("Ape Town", w.site_name)
        self.assertEqual("http://apetown.com", w.site_url)

        # Save again - make sure client_id stays the same among savings.
        client_id = w.client_id
        w.save()
        w = Widget.objects.get(id)
        self.assertEqual(client_id, w.client_id)

        # Clean up.
        Widget.objects.delete(w)

    def test_meta(self):
        w = Widget(website_id=1)
        w.site_name = "The Jungle"
        w.site_url = "http://thejungle.com"
        w.meta["artists"] = ["Michael Jackson", "Gato Barbieri", "Willie Colon"]
        w.save()

        self.assertTrue(w.id > 0)

        w = Widget.objects.get(w.id)
        meta = w.meta
        self.assertTrue(meta != None)

        artists = meta.get("artists", None)
        self.assertTrue(artists != None)
        self.assertEqual(3, len(artists))
        self.assertEqual("Michael Jackson", artists[0])
        self.assertEqual("Gato Barbieri", artists[1])
        self.assertEqual("Willie Colon", artists[2])

        w.delete()

    def test_get_by_id(self):
        w = self._copy_widget(self.w)
        w.save()
        self.assertTrue(w.id > 0)

        w2 = Widget.objects.get(id=w.id)
        self.assertTrue(w2 != None)
        self.assertEqual(w.id, w2.id)

        # Clean up.
        w.delete()

    def test_filter(self):
        w = self._copy_widget(self.w)
        w2 = self._copy_widget(self.w2)
        w3 = Widget(website_id=1, site_name="K", site_url="http://yes.com")

        w.save()
        w2.save()
        w3.save()

        # First case: Retrieve the three of them.
        widgets = Widget.objects.filter(id__in=[w.id, w2.id, w3.id])
        self.assertTrue(widgets != None)
        self.assertEqual(3, len(widgets))

        key_f = lambda widget: widget.id
        widgets = sorted(widgets, key=key_f)
        self.assertEqual(w.id, widgets[0].id)
        self.assertEqual(w2.id, widgets[1].id)
        self.assertEqual(w3.id, widgets[2].id)

        # Second case: Two of them.
        widgets = Widget.objects.filter(id__in=[w.id, w3.id])
        self.assertTrue(widgets != None)
        self.assertEqual(2, len(widgets))

        widgets = sorted(widgets, key=key_f)
        self.assertEqual(w.id, widgets[0].id)
        self.assertEqual(w3.id, widgets[1].id)

        # Third case: one of them.
        widgets = Widget.objects.filter(id__in=[w2.id])
        self.assertTrue(widgets != None)
        self.assertEqual(1, len(widgets))

        self.assertEqual(w2.id, widgets[0].id)

        # Clean up.
        w.delete()
        w2.delete()
        w3.delete()

    def test_delete(self):
        w = self._copy_widget(self.w)
        w2 = self._copy_widget(self.w)

        # Make sure they exist.
        w.save()
        w2.save()

        self.assertTrue(w.id >= 0)
        self.assertTrue(w2.id >= 0)

        id = w.id
        Widget.objects.delete(w)
        try:
            Widget.objects.get(id)
            self.fail("#A1")
        except Widget.DoesNotExist:
            pass

        self.assertEqual(-1, w.id)

        id2 = w2.id
        w2.delete()
        try:
            Widget.objects.get(id2)
            self.fail("#A2")
        except Widget.DoesNotExist:
            pass
        
        self.assertEqual(-1, w2.id)

    def test_monthly_unique_listeners(self):
        """
        Tests that the setters and getters are working
        """
        # Test constructor
        w = Widget(monthly_unique_listeners=2)
        self.assertEqual(w.monthly_unique_listeners, 2)
        self.assertEqual(w.meta['monthly_unique_listeners'], 2)

        w.monthly_unique_listeners = 3
        self.assertEqual(w.monthly_unique_listeners, 3)
        self.assertEqual(w.meta['monthly_unique_listeners'], 3)
