import logging
import os
from os.path import join as pjoin, dirname, abspath
import re
import sys

from django.conf import settings
from django.core.management.base import BaseCommand

from translations.models import TokenTranslation, Token, Locale, Environment

log = logging.getLogger(__name__) # Get an instance of a logger


def get_html_files():
    file_list = []
    rootdir = pjoin(settings.PROJ_ROOT, 'templates')
    for root, subFolders, files in os.walk(rootdir):
        for file in files:
            file_list.append(os.path.join(root,file))
    return file_list


class Command(BaseCommand):
    args = ''
    help = 'Creates empty translation tokens in dev for all languages if they dont exist.'

    def handle(self, *args, **options):

        file_names = get_html_files()
        

        patterns = [re.compile('({%)[ ]?(trans )(\')(?P<token_key>.*?)(\')[ ]?(%})'),
                    re.compile('({%)[ ]?(trans )(")(?P<token_key>.*?)(")[ ]?(%})'), ]

        keys = {  }

        for file_name in file_names:
            f = open(file_name, 'rb')
            for line in f:
                for regex in patterns:
                    groups = regex.findall(line)
                    for group in groups:
                        key = group[3]
                        keys[key] = key
        

        print '\n\nFound {0} translation keys in total in {1} files.'.format(len(keys.keys()), len(file_names))

        environment = Environment.objects.get(name='dev')
        
        tokens_created = 0

        for l in settings.LANGUAGES:
            language_code = l[0]
            language_name = l[1]

            affected_count = 0
            
            locale, created = Locale.objects.get_or_create(locale=language_code, defaults={ 'name': language_name })

            if created:
                print '{1} didnt exist as a language in dev, so it was created.'.format(language_name)

            for key in keys:
                key = key.strip()
                token, created = Token.objects.get_or_create(key=key)
                if created:
                    tokens_created += 1
                

                translation, created = TokenTranslation.objects.get_or_create(token=token, \
                        environment=environment, \
                        locale=locale, defaults={  } )

                if created:
                    affected_count += 1

            print 'Finished processing {0} - created {1} new translations.'.format( language_name, affected_count)
        
        print 'Created {0} missing tokens.\n\n'.format(tokens_created)

        count = 0
