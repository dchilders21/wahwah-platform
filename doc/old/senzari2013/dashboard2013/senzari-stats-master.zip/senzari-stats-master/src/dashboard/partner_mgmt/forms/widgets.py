#coding=utf-8
from datetime import date
from django.conf import settings
from django.contrib.auth.models import User
from django.forms import widgets
from django.utils.safestring import mark_safe
from django.core.urlresolvers import reverse
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.utils.translation import string_concat
from translations import ugettext as _
from auth.models import User, Profile, Address, Phonenumber
from partner_mgmt.models import WidgetUser, Widget
from utils import forms

BASE_URL = getattr(settings, 'BASE_URL')


SUPPORTED_COUNTRIES = (
    (3, 'Brazil'),
    (2, 'Spain'),
    (1, 'United States of America'),
)

SUPPORTED_LANGUAGES = (
    ('en', _('English')),
    ('pt', _('Portuguese')),
    ('es', _('Spanish')),
)

TRAFFIC_ESTIMATES = (
    ('0-10,000', 'Up to 10k'),
    ('10,000-100,000', '10k - 100k'),
    ('100,000-200,000', '100k - 200k'),
    ('200,000-500,000', '200k - 500k'),
    ('500,000-1,000,000', '500k - 1M'),
    ('1,000,000-5,000,000', '1M or more'),
)

WEBSITE_TYPES = (
    ('PERSONAL_BLOG', 'Personal Blog'),
    ('MUSIC', 'Music'),
    ('PEOPLE_SOCIETY', 'People & Society'),
    ('ARTS_ENTERTAINMENT', 'Arts & Entertainment'),
    ('NEWS', 'News'),
    ('ONLINE_COMMUNITY', 'Online Community'),
    ('GAMING', 'Gaming'),
    ('E_COMMERCE', 'E-commerce'),
    ('OTHER', 'Other'),
)

SKIN_COLOR = (
    ('DARK', 'Dark'),
    ('LIGHT', 'Light'),
)


class WidgetUserForm(forms.Form):
    delete_user = forms.IntegerField(required=False)
    name = forms.CharField(max_length=255, required=False)
    email = forms.EmailField(required=False)

    current_password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Current Password'}), required=False)
    new_password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'New Password'}), required=False)

    def __init__(self, *args, **kwargs):
        widget = kwargs.pop('widget') if 'widget' in kwargs else None
        super(WidgetUserForm, self).__init__(*args, **kwargs)
        self.widget = widget
        self.user = getattr(kwargs.get('request'), 'user', None)

    def clean_delete_user(self):
        delete_user = self.cleaned_data['delete_user']

        try:
            widget_user = self.widget.users.filter(id=delete_user)[0]
            if self.user and self.user.id == widget_user.user.id:
                raise forms.ValidationError("You cannot delete yourself")
            elif widget_user.role == 'owner':
                raise forms.ValidationError("You cannot delete the owner")

        except IndexError:
            pass

        if delete_user and not self.widget.users.exclude(role='owner').filter(id=delete_user).exists():
            raise forms.ValidationError("User does not exist, or you're not authorized to delete it")

        return delete_user

    def clean(self):
        data = super(WidgetUserForm, self).clean()

        name = data.get('name')
        email = data.get('email')
        delete_user = data.get('delete_user')

        if not delete_user and 'delete_user' in self.errors:
            delete_user = True

        if not delete_user:
            if not (name and email):
                raise forms.ValidationError("Please enter a valid name and email")
            elif name and email:
                if self.widget.users.filter(email=email).exists():
                    raise forms.ValidationError("{0} has already been invited, that person cannot be invited again".format(name))

        return data

    def parse(self):
        data = self.cleaned_data
        del data["delete_user"]
        return data

    def delete(self):
        data = self.cleaned_data
        delete_user = data.get('delete_user')
        if delete_user:
            user = self.widget.users.filter(id=delete_user)
            user.delete()

    def save(self):
        data = self.cleaned_data
        name = data.get('name')
        email = data.get('email')

        try:
            auth_user = User.objects.get(email=email)
        except User.DoesNotExist:
            auth_user = None

        user = WidgetUser(user=auth_user, email=email, widget=self.widget, role='users')
        user.meta = {'name': name}
        user.save()

        # TODO : move this into the model, doesnt belong here
        # If already a user, don't email
        if not auth_user:
            email = EmailMessage(subect='Join today!',
                                    from_email='noreply@senzari.com',
                                    to=(email,))
            email.content_subtype = "html"  # Main content is now text/html
            email.body = name + "<br><a href=\"http://{0}".format(BASE_URL) + reverse('register') + "\">register</a>"
            # email.body = render_to_string("template", {})
            email.send()

        return user

default_url_error = {
    'invalid': _('message.url.error')
}
class WidgetForm(forms.Form):
    """
    This form is for editing the widget
    """
    site_name = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'placeholder': _('site.settings.field.site_name')}))
    site_url = forms.URLField(error_messages=default_url_error, widget=forms.TextInput(attrs={'placeholder': 'http://www.example.com/'}))
    contact_name = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'placeholder': _('site.settings.field.contact_name')}))
    contact_email = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'placeholder': _('site.settings.field.contact_email')}))
    analytics_id = forms.CharField(max_length=16, required=False, widget=forms.TextInput(attrs={'placeholder': 'UA-######-##', 'disabled': None}))
    inactive = forms.BooleanField(required=False, initial=False)

    website_ids = forms.MultipleChoiceField(choices=SUPPORTED_COUNTRIES, widget=forms.CheckboxSelectMultiple(attrs={'class': 'checkbox'}))
    language = forms.ChoiceField(choices=SUPPORTED_LANGUAGES, widget=forms.Select(attrs={'class': 'customSelect'}))
    website_type = forms.ChoiceField(choices=WEBSITE_TYPES, widget=forms.Select(attrs={'class': 'customSelect'}))
    skin_color = forms.ChoiceField(choices=SKIN_COLOR, widget=forms.Select(attrs={'class': 'customSelect'}))

    def __init__(self, *args, **kwargs):
        self.saved = False
        self.user = kwargs.pop('user', None)
        self.widget = kwargs.get('instance', None)

        self.instance = kwargs.pop('instance', None)

        super(WidgetForm, self).__init__(*args, **kwargs)

        fields = ['site_name', 'site_url', 'website_ids', 'language',
                  'analytics_id', 'contact_name', 'contact_email',
                  'website_type', 'skin_color', 'inactive']

        if self.instance:
            self.fields['inactive'].initial = not self.instance.is_active


        if self.user and not self.instance:
            self.fields['contact_name'].initial = u"{0} {1}".format(self.user.first_name, self.user.last_name)
            self.fields['contact_email'].initial = self.user.email

        # Set the labels
        for field in fields:
            # If we have an instance, then we need to make sure we set the
            # initial value as well.
            try:
                value = getattr(self.instance, field, None)
            except KeyError:
                value = ''

            if self.instance and value:
                self.fields[field].initial = value

    def clean_website_ids(self):
        website_ids = self.cleaned_data['website_ids'] or []
        return [int(x) for x in website_ids]

    def save(self):
        if not self.user:
            raise Exception("User has to be specified")

        if not self.is_valid():
            raise Exception("Form has to be valid before saving")

        data = self.cleaned_data

        widget = self.widget or Widget()
        widget.partner_id = 1
        widget.site_name = data.get('site_name')
        widget.site_url = data.get('site_url')
        widget.is_active = not data.get('inactive', False)
        widget.website_ids = data.get('website_ids', [])
        try:
            widget.website_id = widget.website_ids[0]
        except IndexError:
            pass

        widget.language = data.get('language')
        widget.monthly_unique_listeners = ''
        widget.analytics_id = data.get('analytics_id')
        widget.website_type = data.get('website_type')
        widget.contact_name = data.get('contact_name')
        widget.contact_email = data.get('contact_email')
        widget.skin_color = data.get('skin_color')
        widget.network = Profile.objects.get(user=self.user).network
        widget.save()

        widget_user, created = WidgetUser.objects.get_or_create(user=self.user, widget_id=widget.id)

        self.saved = True
        return widget
