from __future__ import with_statement
import logging, re

from django.conf import settings
from django.core.cache import get_cache
from django.template import (Node, Variable, TemplateSyntaxError,
    TokenParser, Library, TOKEN_TEXT, TOKEN_VAR)
from django.template.base import _render_value_in_context, Template, TemplateSyntaxError, VariableDoesNotExist
from django.template.defaulttags import token_kwargs
from django.templatetags.i18n import GetCurrentLanguageNode, GetLanguageInfoListNode
from django.utils import translation, safestring
from django.utils.text import (smart_split, unescape_string_literal,
    get_text_list)
from django.utils.safestring import (SafeData, EscapeData, mark_safe,
    mark_for_escaping)
from django.utils.translation import ugettext_lazy, pgettext_lazy, ugettext

# To support python >= 2.7
try:
    from ..translations.models import TokenKey, TokenTranslation, Token, Environment, Locale
except ImportError:
    from translations.models import TokenKey, TokenTranslation, Token, Environment, Locale


log = logging.getLogger(__name__)  # Get an instance of a logger

register = Library()

ENVIRONMENT = getattr(settings, 'ENVIRONMENT', 'dev')
GET_TRANSLATION_TOKENS_SECONDS = getattr(settings, 'GET_TRANSLATION_TOKENS_SECONDS')
RUNNING_LOCALLY = getattr(settings, 'RUNNING_LOCALLY', False)


class TranslationVariable(Variable):
    """
    In order to override the translation lookup, we had to yank out a lot of
    the internals of the trans tag.
    """

    def __init__(self, var):
        self._locale = None
        super(TranslationVariable, self).__init__(var)

    def locale(self, context):
        request = context.get('request')

        if not self._locale and request:
            self._locale = translation.get_language_from_request(request)[:2]

        if not self._locale:
            self._locale = translation.get_language()[:2]

        return self._locale

    def resolve(self, context):
        """Resolve this variable against a given context."""
        if self.lookups is not None:
            # We're dealing with a variable that needs to be resolved
            try:
                value = self._resolve_lookup(context)
            except VariableDoesNotExist:
                self.translate = True
                value = self.var
        else:
            # We're dealing with a literal, so it's already been "resolved"
            value = self.literal

        if self.translate:
            #
            # This is where all the action is; this code in this class,
            # in TranslateNode and in do_translate was forked in Django
            # > 1.3, so all this code will need refactoring if we upgrade.
            #
            # If that ever happens (lolz), pls reference
            #  https://github.com/django/django/blob/1.3.X/django/template/base.py
            #  https://github.com/django/django/blob/1.3.X/django/templatetags/i18n.py
            #

            locale = self.locale(context)
            key = TokenKey(value, locale=locale)

            if not settings.USE_DB_TRANSLATIONS:
                value = gettext(key.token_key) or key.token_key
            else:
                # Step 1. look up key in memcached.

                if RUNNING_LOCALLY and ENVIRONMENT == 'dev':
                    cache = get_cache('default')
                else:
                    cache = get_cache('prod')

                value = cache.get(key.cache_key)

                if value:
                    log.debug(u'CACHE: %s' % key.cache_key)
                    return safestring.mark_safe(value)

                try:
                    # Get token for current environment and language.
                    token = TokenTranslation.objects.filter(token__key=key.token_key, environment__name=ENVIRONMENT, locale__locale__iexact=locale)[0]
                    value = token.value or token.token.key

                    if token.value:
                        try:
                            value = Template(value).render(context)
                        except TemplateSyntaxError:
                            log.warning(u'DB: TemplateSyntaxError on key %s' % token.token.key)
                            value = token.token.key

                    log.debug(u'DB: getting %s' % key.cache_key)
                    cache.set(key.cache_key, value, GET_TRANSLATION_TOKENS_SECONDS)

                except IndexError:
                    log.debug(u'DB: creating %s' % key.cache_key)

                    # This logic ensures that a token, and a token translation
                    # is created in case it does not exist.

                    # Remove this later? It facilitates migrating
                    # our tokens.
                    (t, created) = Token.objects.get_or_create(key=key.token_key)
                    (e, created) = Environment.objects.get_or_create(name=ENVIRONMENT, defaults={ 'order': 0 })
                    (l, created) = Locale.objects.get_or_create(locale=locale, defaults={ 'name': locale })

                    tmp_value = ugettext(key.token_key) if locale == 'en' else ''

                    # We dont want to store the token key in the DB!
                    tmp_value = tmp_value if tmp_value != key.token_key else ''

                    # This helps fill in the translation values for us.
                    (token, created) = TokenTranslation.objects.get_or_create(token=t, environment=e, locale=l, defaults={ 'value': tmp_value })
                    value = tmp_value or key.token_key

            if value == None:
                value = ''

        return safestring.mark_safe(value)


    def __repr__(self):
        return "<%s: %r>" % (self.__class__.__name__, self.var)

    def __str__(self):
        return self.var


class TranslateNode(Node):

    def __init__(self, filter_expression, noop):
        self.noop = noop
        self.filter_expression = filter_expression
        if isinstance(self.filter_expression.var, basestring):
            self.filter_expression.var = TranslationVariable(u"'%s'" % self.filter_expression.var)

    def render(self, context):
        self.filter_expression.var.translate = not self.noop
        output = self.filter_expression.resolve(context)
        return _render_value_in_context(output, context)


@register.tag("get_current_language")
def do_get_current_language(parser, token):
    """
    This will store the current language in the context.

    Usage::

        {% get_current_language as language %}

    This will fetch the currently active language and
    put it's value into the ``language`` context
    variable.
    """
    args = token.contents.split()
    if len(args) != 3 or args[1] != 'as':
        raise TemplateSyntaxError("'get_current_language' requires 'as variable' (got %r)" % args)
    return GetCurrentLanguageNode(args[2])


@register.tag("get_language_info_list")
def do_get_language_info_list(parser, token):
    """
    This will store a list of language information dictionaries for the given
    language codes in a context variable. The language codes can be specified
    either as a list of strings or a settings.LANGUAGES style tuple (or any
    sequence of sequences whose first items are language codes).

    Usage::

        {% get_language_info_list for LANGUAGES as langs %}
        {% for l in langs %}
          {{ l.code }}
          {{ l.name }}
          {{ l.name_local }}
          {{ l.bidi|yesno:"bi-directional,uni-directional" }}
        {% endfor %}
    """
    args = token.contents.split()
    if len(args) != 5 or args[1] != 'for' or args[3] != 'as':
        raise TemplateSyntaxError("'%s' requires 'for sequence as variable' (got %r)" % (args[0], args[1:]))
    return GetLanguageInfoListNode(args[2], args[4])


@register.tag("trans")
def do_translate(parser, token):
    """
    This will mark a string for translation and will
    translate the string for the current language.

    Usage::

        {% trans "this is a test" %}

    This will mark the string for translation so it will
    be pulled out by mark-messages.py into the .po files
    and will run the string through the translation engine.

    There is a second form::

        {% trans "this is a test" noop %}

    This will only mark for translation, but will return
    the string unchanged. Use it when you need to store
    values into forms that should be translated later on.

    You can use variables instead of constant strings
    to translate stuff you marked somewhere else::

        {% trans variable %}

    This will just try to translate the contents of
    the variable ``variable``. Make sure that the string
    in there is something that is in the .po file.
    """
    class TranslateParser(TokenParser):
        def top(self):
            value = self.value()

            # Backwards Compatiblity fix:
            # FilterExpression does not support single-quoted strings,
            # so we make a cheap localized fix in order to maintain
            # backwards compatibility with existing uses of ``trans``
            # where single quote use is supported.
            if value[0] == "'":
                pos = None
                m = re.match("^'([^']+)'(\|.*$)",value)
                if m:
                    value = '"%s"%s' % (m.group(1).replace('"','\\"'),m.group(2))
                elif value[-1] == "'":
                    value = '"%s"' % value[1:-1].replace('"','\\"')

            if self.more():
                if self.tag() == 'noop':
                    noop = True
                else:
                    raise TemplateSyntaxError("only option for 'trans' is 'noop'")
            else:
                noop = False
            return (value, noop)
    value, noop = TranslateParser(token.contents).top()
    return TranslateNode(parser.compile_filter(value), noop)

