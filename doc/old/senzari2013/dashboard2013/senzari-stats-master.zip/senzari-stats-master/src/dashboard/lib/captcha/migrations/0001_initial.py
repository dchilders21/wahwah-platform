
from south.db import db
from django.db import models
from captcha.models import *

class Migration:
    
    def forwards(self, orm):
        
        # Adding model 'CaptchaStore'
        db.create_table('captcha_captchastore', (
            ('id', orm['captcha.CaptchaStore:id']),
            ('challenge', orm['captcha.CaptchaStore:challenge']),
            ('response', orm['captcha.CaptchaStore:response']),
            ('hashkey', orm['captcha.CaptchaStore:hashkey']),
            ('expiration', orm['captcha.CaptchaStore:expiration']),
        ))
        db.send_create_signal('captcha', ['CaptchaStore'])
        
    
    
    def backwards(self, orm):
        
        # Deleting model 'CaptchaStore'
        db.delete_table('captcha_captchastore')
        
    
    
    models = {
        'captcha.captchastore': {
            'challenge': ('django.db.models.fields.CharField', [], {'max_length': '32'}),
            'expiration': ('django.db.models.fields.DateTimeField', [], {}),
            'hashkey': ('django.db.models.fields.CharField', [], {'max_length': '40', 'unique': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'response': ('django.db.models.fields.CharField', [], {'max_length': '32'})
        }
    }
    
    complete_apps = ['captcha']
