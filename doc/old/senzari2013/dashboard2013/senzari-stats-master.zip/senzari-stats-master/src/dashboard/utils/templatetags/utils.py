import copy
from datetime import date

from django.db.models.query import QuerySet
from django.core.serializers import serialize
from django.core.urlresolvers import reverse
from django.template import Library
from django.utils import simplejson
from django.utils.datastructures import SortedDict
from django.utils.safestring import SafeUnicode, SafeString

#from django.utils.html import escape
#from django.template import Library, Node
#from django.utils.translation import ugettext as _


register = Library()

@register.filter
def formfields(form, fields):
    fields = [f.strip() for f in fields.split(',')]
    new_fields = []
    for name in fields:
        field = form.fields.get(name)
        if field:
            new_fields.append((name, field))
    new_form = copy.copy(form)
    new_form.fields = SortedDict(new_fields)
    return new_form


@register.filter(name='field_type')
def field_type(field, ftype):
    try:
        t = field.field.widget.__class__.__name__
        return t.lower() == ftype
    except:
        return False

@register.filter(name='field')
def field(field, ftype):
    try:
        t = field.field.__class__.__name__
        return t.lower() == ftype.lower()
    except:
        return False

@register.filter
def is_active(request, url):
	url = reverse(url)
	if request == None:
		return False
	is_active = False
	current_url = request.path
	if url != SafeUnicode('/'):
		is_active = SafeUnicode(current_url).startswith(url)
	else:
		is_active = url == SafeUnicode(current_url)

	return is_active

@register.filter
def subnav_is_active(request, url):
	url = reverse(url)
	if request == None:
		return False
	is_active = False
	current_url = request.path
	is_active = url == SafeUnicode(current_url)
	return is_active

@register.filter
def jsonify(object):
    if isinstance(object, QuerySet):
        return serialize('json', object)
    return simplejson.dumps(object)

@register.filter
def is_viewable_by(widget_user, current_user):
    if isinstance(widget_user, dict):
        return True

    return widget_user.is_viewable_by(current_user)
