#coding=utf-8
from datetime import date
import hashlib
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.core.urlresolvers import reverse
from django.utils.safestring import mark_safe
from django.utils.translation import string_concat
from translations import ugettext as _
from django.forms import widgets
from django.forms.widgets import Select

#from captcha.fields import CaptchaField, CaptchaTextInput

from registration.forms import RegistrationFormUniqueEmail
from partner_mgmt.models import WidgetNetwork
from auth.models import User, Profile
from utils import forms


class PasswordField(forms.CharField):
    max_length=100
    widget=forms.PasswordInput()


class SessionMixin(object):
    def clean(self):
        result = super(SessionMixin, self).clean()
        if self.request:
            if not self.request.session.test_cookie_worked():
                raise forms.ValidationError(_("Your Web browser doesn't "
                    "appear to have cookies enabled. Cookies are required "
                    "for logging in."))
        return result


class RegistrationForm(forms.FormMixin, RegistrationFormUniqueEmail):

    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    #captcha = CaptchaField()
    accepted_terms = forms.BooleanField(required=True)

    def __init__(self, *args, **kwargs):

        super(RegistrationForm, self).__init__(*args, **kwargs)

        accept_url = reverse('terms-of-service')
        accept_text = [
            _('register.form.field.accept'),
            u' <a href="{0}">'.format(accept_url),
            _('register.form.field.accept.link'),
            u'</a>',
        ]

        self.fields['email'].label = _('register.form.field.email')
        self.fields['email'].max_length = 254
        self.fields['password1'].label = _('register.form.field.password1')
        self.fields['password2'].required = False
        self.fields['username'].required = False

        # take out some fields.
        self.fields['password2'].widget = widgets.HiddenInput()
        self.fields['username'].widget = widgets.HiddenInput()

        #self.fields['captcha'].label = _('register.form.field.captcha')
        self.fields['accepted_terms'].label = mark_safe(string_concat(*accept_text))

        for field in self.fields:
            #if type(self.fields[field].widget) in [widgets.TextInput, widgets.Textarea, widgets.PasswordInput, CaptchaTextInput]:
            if type(self.fields[field].widget) in [widgets.TextInput, widgets.Textarea, widgets.PasswordInput]:
                self.fields[field].widget.attrs = { 'placeholder': self.fields[field].label }

    def clean_username(self):
        """
        Since we are not using the username, we
        should just hash the email.
        """
        return ''

    def clean_email(self):
        data = self.cleaned_data['email']

        if len(data) > self.fields['email'].max_length:
            raise forms.ValidationError(u'Email address is too long.')
        elif User.objects.filter(email__iexact=data).exists():
            raise forms.ValidationError(u'Another user is registered with this email.')

        return data

    def clean_password2(self):
        try:
            password1 = self.cleaned_data['password1']
            return password1
        except KeyError:
            return ''


    def save(self, request, **kwargs):

        send_email = kwargs.get('send_email', True)

        company = ''
        email = self.cleaned_data['email']
        email = email.lower()
        username =  hashlib.md5(email).hexdigest()[:30]
        password = self.cleaned_data['password1']
        first_name = self.cleaned_data['first_name']
        last_name = self.cleaned_data['last_name']

        user = User.objects.create_user(username, email, password)
        user.is_active = False
        user.save()
        profile, created = Profile.objects.get_or_create(user=user)
        profile.company = company
        profile.first_name = first_name
        profile.last_name = last_name
        try:
            profile.network = WidgetNetwork.objects.get(id=request.GET.get('networkid'))
        except WidgetNetwork.DoesNotExist:
            pass
        profile.save()

        profile.set_activation_key()

        if send_email:
            profile.send_activation_email()

        return user


    class Meta:
        fields = ['first_name', 'last_name', 'email', 'password1', 'password2', 'accepted_terms', 'username']


class AuthenticationForm(forms.Form):
    """
    Base class for authenticating users. Extend this to get a form that accepts
    username/password logins.
    """
    email = forms.EmailField(label=_("Email"), max_length=254)
    password = forms.CharField(label=_("Password"), widget=forms.PasswordInput)

    def __init__(self, request=None, *args, **kwargs):
        """
        If request is passed in, the form will validate that cookies are
        enabled. Note that the request (a HttpRequest object) must have set a
        cookie with the key TEST_COOKIE_NAME and value TEST_COOKIE_VALUE before
        running this validation.
        """
        self.request = request
        self.user_cache = None
        super(AuthenticationForm, self).__init__(*args, **kwargs)

    def clean(self):
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')

        if email and password:
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                user = None

            if not user:
                raise forms.ValidationError(_("Please enter a correct email and password. Note that both fields are case-sensitive."))

            self.user_cache = authenticate(username=user.username, password=password)
            if self.user_cache is None:
                raise forms.ValidationError(_("Please enter a correct email and password. Note that both fields are case-sensitive."))
            elif not self.user_cache.is_active:
                raise forms.ValidationError(_("This account is inactive."))

        # TODO: determine whether this should move to its own method.
        if self.request:
            if not self.request.session.test_cookie_worked():
                raise forms.ValidationError(_("Your Web browser doesn't appear to have cookies enabled. Cookies are required for logging in."))

        return self.cleaned_data

    def get_user_id(self):
        if self.user_cache:
            return self.user_cache.id
        return None

    def get_user(self):
        return self.user_cache


