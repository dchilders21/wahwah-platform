import logging
import simplejson
import time

from django.db import connections
from django.conf.urls.defaults import *
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.core.urlresolvers import reverse

from tastypie import fields
from tastypie.exceptions import ImmediateHttpResponse
from tastypie.http import HttpUnauthorized, HttpBadRequest, HttpForbidden
from tastypie.resources import ALL_WITH_RELATIONS
from tastypie.utils import trailing_slash

from ..base import AttrDict, StatsResource, DjangoAuthentication

log = logging.getLogger(__name__)  # Get an instance of a logger

class UsersRegisteredResource(StatsResource):
    """ User registered stats resource """

    def override_urls(self):
        return [
                url(r"^(?P<resource_name>%s)%s$" % (self._meta.resource_name, trailing_slash()), self.wrap_view('dispatch_list'), name="api_users_list"),
            ]

    def get_values(self, request, **kwargs):
        cursor = connections['prod'].cursor()
        sql = """
            SELECT date_trunc('day', date_joined) AS "day" , count(*) AS "count"
            FROM auth_user
            WHERE date_joined > now() - interval %s
            GROUP BY 1
            ORDER BY 1 ASC;

        """
        period = self.parse_period (request.GET.get ('period', ''))
        cursor.execute(sql, [period])
        data = cursor.fetchall()

        items = []
        for x in data:
            day = x[0]

            day_unix = time.mktime(day.timetuple())+float("0.%s"%day.microsecond)

            items.append(AttrDict(x=day_unix, y=x[1] ))
        return items

    class Meta:
        key = 'Users registered'
        resource_name = 'stats/users/registered'
        list_allowed_methods = ['get',]
        authentication = DjangoAuthentication()


class DaysSinceLoginResource(StatsResource):
    """ Stations listened resource """
    def get_resource_uri(self, *args, **kwargs):
        return ''

    def get_values(self, request, **kwargs):
        cursor = connections['prod'].cursor()
        sql = """
            SELECT
		        date_trunc('day', now()) - date_trunc('day', last_login),
		        count(*) AS "count"
            FROM auth_user
            GROUP BY 1
            ORDER BY 1 ASC;
        """
        cursor.execute(sql)
        data = cursor.fetchall()

        items = []
        for x in data:
            # delta = x[0] - datetime.datetime.now()
            day = x[0]
            items.append(AttrDict(x=day.days, y=x[1]))
        return items

    class Meta:
        key = 'Days since last login'
        resource_name = 'stats/users/time-since-login'
        list_allowed_methods = ['get',]

