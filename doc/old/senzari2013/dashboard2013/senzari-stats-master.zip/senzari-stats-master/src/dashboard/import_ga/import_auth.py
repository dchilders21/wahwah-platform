
import httplib2
from os import path
from apiclient.discovery import build
from oauth2client.client import flow_from_clientsecrets
from oauth2client.file import Storage
from oauth2client.tools import run

CLIENT_SECRETS = path.join(
    path.dirname(path.realpath(__file__)),
    'client_secrets.json')

FLOW = flow_from_clientsecrets(CLIENT_SECRETS,
    scope = 'https://www.googleapis.com/auth/analytics.readonly',
    message = 'Missing client_secrets file')

TOKEN_FILE_NAME = path.join(
    path.dirname(path.realpath(__file__)),
    'analytics.dat')

def prepare_credentials():
    storage = Storage(TOKEN_FILE_NAME)
    credentials = storage.get()

    if not credentials or credentials.invalid:
        credentials = run(FLOW, storage)

    return credentials

def initialize_service():
    credentials = prepare_credentials()
    http = httplib2.Http()
    http = credentials.authorize(http)

    return build('analytics', 'v3', http=http)



