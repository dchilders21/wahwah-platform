
from django.contrib import admin
from .models import Profile

class ProfileAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'activation_key', 'network', )
    list_filter = ('status', 'network', )
    search_fields = ['user__first_name', 'user__last_name',  'user__email', ]
    raw_id_fields = ('user',)


admin.site.register(Profile, ProfileAdmin)

