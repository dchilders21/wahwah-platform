{
  graphitePort: 2003
, graphiteHost: "localhost"
, port: 8125
, debug: true
, deleteIdleStats: true
, sentryDNS: "https://d3adf602e5db4f61bb7731fdbc0c7f4f:a75fff5b866d43a28f48bac576fbe02f@app.getsentry.com/14051"
}
