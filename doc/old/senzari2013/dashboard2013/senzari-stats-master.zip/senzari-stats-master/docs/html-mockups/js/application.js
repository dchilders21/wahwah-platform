jQuery(document).ready(function($) {
  $('#myModal').modal('toggle');
});
